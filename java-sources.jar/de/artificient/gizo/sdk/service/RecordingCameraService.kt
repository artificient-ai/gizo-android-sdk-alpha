package de.artificient.gizo.sdk.service

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
import android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
import android.media.MediaPlayer
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.widget.Toast
import androidx.camera.view.PreviewView
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationCompat.CATEGORY_SERVICE
import androidx.core.app.NotificationCompat.PRIORITY_MAX
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.app.TaskStackBuilder
import androidx.core.os.bundleOf
import androidx.lifecycle.*
import de.artificient.gizo.sdk.Gizo
import de.artificient.gizo.sdk.GizoAppOptionsDelegate
import de.artificient.gizo.sdk.R
import de.artificient.gizo.sdk.core.GizoAnalysisImpl
import de.artificient.gizo.sdk.core.GizoProvider
import de.artificient.gizo.sdk.core.common.util.getAppIcon
import de.artificient.gizo.sdk.model.FileLocationPath
import de.artificient.gizo.sdk.service.RecordingBackgroundService.Companion
import kotlinx.coroutines.launch
import java.util.*

internal class RecordingCameraService : LifecycleService() {

    companion object {
        private val TAG = RecordingCameraService::class.simpleName
        const val ACTION_START_WITH_PREVIEW: String = "ACTION_START_WITH_PREVIEW"
        const val ACTION_STOP_RECORDING: String = "ACTION_STOP_RECORDING"
        const val ACTION_START_RECORDING: String = "ACTION_START_RECORDING"
        const val BIND_USECASE: String = "bind_usecase"
        const val CHANNEL_NAME: String = "recording service"
        const val CHANNEL_ID: String = "recording_service"
        const val ONGOING_NOTIFICATION_ID: Int = 2345

        fun isRunning(context: Context): Boolean {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            for (service in manager.getRunningServices(Integer.MAX_VALUE)) {
                if (RecordingCameraService::class.java.name == service.service.className) {
//                    Log.d(TAG, "isRunning")
                    return true
                }
            }
            return false
        }
    }

    private val pendingActions: HashMap<String, Runnable> = hashMapOf()

    private lateinit var dangerPlayer: MediaPlayer

    var previewView2: PreviewView? = null

    class RecordingServiceBinder(private val service: RecordingCameraService) : Binder() {
        fun getService(): RecordingCameraService {
            return service
        }
    }

    private lateinit var viewModel: GizoAnalysisImpl

    val options = Gizo.options
    val optionsDelegate = GizoAppOptionsDelegate(options = options)

    private var isItHasNotification = false

    private lateinit var recordingServiceBinder: RecordingServiceBinder

    private var startTime: Long = Date().time

    private var backgroundTime: Long? = null
    override fun onCreate() {
        // Provide dependencies to GizoAnalysis
        viewModel = GizoProvider.provideGizoAnalysis(applicationContext, optionsDelegate) as GizoAnalysisImpl
        super.onCreate()
//        viewModel.initialViewModel()
//        if (RecordingBackgroundService.isRunning(this).not()) {
//            viewModel.registerGeofencing()
//            viewModel.bindMapNavigation(this)
//            viewModel.stillPauseStart {
//                viewModel.changeRecordState(RecordingState.STILL)
//            }
//        }
//
//        viewModel.setBackgroundAnalysisAlive(true)
        startTime = Date().time
//        Log.d(TAG, "service onCreate")
        recordingServiceBinder = RecordingServiceBinder(this)
////        dangerPlayer = MediaPlayer.create(this, R.raw.alert_danger)
//        lifecycleScope.launch {
//            viewModel.uiState
//                .flowWithLifecycle(lifecycle)
//                .collect {
//                    updateNotification(isRecording = it.isRecording)
//                }
//        }
//        lifecycleScope.launch {
//            viewModel.ttcDangerFlow
//                .flowWithLifecycle(lifecycle)
//                .collect {
//                    if (it) {
//                        if (dangerPlayer.isPlaying.not())
//                            dangerPlayer.start()
//                    }
//                }
//        }
//        lifecycleScope.launch {
//            viewModel.eventBackground
//                .flowWithLifecycle(lifecycle)
//                .collect { event ->
//                    when (event) {
//                        is RecordingUiEvent.Error -> {
//                            Toast.makeText(applicationContext, event.message, Toast.LENGTH_SHORT)
//                                .show()
//                        }
//
//                        is RecordingUiEvent.Alert -> {
//                            Toast.makeText(applicationContext, event.message, Toast.LENGTH_SHORT)
//                                .show()
//                        }
//
//                        else -> {}
//                    }
//                }
//        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
//        Log.d(TAG, "service onStartCommand action: " + intent?.action)
//        viewModel.attachMapNavigationObserver()
        when (intent?.action) {
            ACTION_START_WITH_PREVIEW -> {
                if (viewModel.cameraInitialized.not()) {
                    initializeCamera()
                }
            }

//            ACTION_START_RECORDING -> {
//                if (viewModel.cameraInitialized)
//                    viewModel.startRecordingVideo()
//
//            }

            ACTION_STOP_RECORDING -> {
                val fileLocationPath = FileLocationPath.CACHE
                if (viewModel.cameraInitialized)
                    viewModel.stopRecordingVideo(fileLocationPath)
            }
        }
        return START_NOT_STICKY
    }

    private fun initializeCamera() {
//        Log.d(TAG, "service initializeCamera")
//        Log.d(TAG, "service createVideoCaptureUseCase")
        viewModel.initialCamera(lifecycleOwner = this) {
//            Log.d(TAG, "service createVideoCaptureUseCase Done")
            val action = pendingActions[BIND_USECASE]
            action?.run()
            pendingActions.remove(BIND_USECASE)
        }
    }

    fun bindPreviewUseCase(previewView: PreviewView?) {
//        Log.d(TAG, "service bindPreviewUseCase")
        if (viewModel.cameraInitialized) {
            previewView2 = previewView
            bindInternal(previewView)
        } else {
            pendingActions[BIND_USECASE] = Runnable {
                bindInternal(previewView)
            }
        }
    }

    private fun stopForeground() {
        backgroundTime?.let { start ->
//            Log.d(TAG, "service stopForeground duration :" + (Date().time - start))
            backgroundTime = null
        }

//        Log.d(TAG, "service stopForeground")
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_DETACH)

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(ONGOING_NOTIFICATION_ID)
        isItHasNotification = false
    }

    private fun bindInternal(previewView: PreviewView?) {
        stopForeground()
//        Log.d(TAG, "service bindInternal")
        if (previewView != null) {
//            Log.d(TAG, "service bindInternal has preview")
            viewModel.attachPreview(previewView)
        }
    }

    private fun buildNotification(isRecording: Boolean): Notification {
        val parentStack = TaskStackBuilder.create(this)
//            .addNextIntentWithParentStack(Intent(this, RecordingCameraActivity::class.java))

        val recordingIntent = Intent(this, RecordingCameraService::class.java).apply {
            action = if (isRecording) ACTION_STOP_RECORDING else ACTION_START_RECORDING
        }
        val recordingPendingIntent: PendingIntent =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                PendingIntent.getForegroundService(
                    this,
                    0,
                    recordingIntent,
                    PendingIntent.FLAG_IMMUTABLE
                )
            } else {
                PendingIntent.getService(this, 0, recordingIntent, PendingIntent.FLAG_IMMUTABLE)
            }

        val actionText = if (isRecording) "Stop Recording" else "Start Recording"
        val actionIconRes = 0


        val contentTitle = "GIZO Analysis"

        val contentText =
            if (isRecording) "Video recording in background" else "Video Analysis in background"

        val pendingIntent1 = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            parentStack.getPendingIntent(0, PendingIntent.FLAG_IMMUTABLE)
        } else {
            parentStack.getPendingIntent(0, 0)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setOngoing(true)
            .setContentTitle(contentTitle)
            .setContentText(contentText)
            .setSmallIcon(getAppIcon(this))
            .setContentIntent(pendingIntent1)
            .setPriority(PRIORITY_MAX)
            .setOnlyAlertOnce(true)
            .setCategory(CATEGORY_SERVICE)
            .setAutoCancel(false)
            .addAction(
                actionIconRes, actionText,
                recordingPendingIntent
            )
            .build()
    }

    @SuppressLint("MissingPermission")
    private fun updateNotification(isRecording: Boolean) {
        if (isItHasNotification) {
            val notification: Notification = buildNotification(isRecording = isRecording)
            with(NotificationManagerCompat.from(this)) {
                notify(ONGOING_NOTIFICATION_ID, notification)
            }

        }
    }


    fun startRunningInForeground() {
//        Log.d(TAG, "service startRunningInForeground")
        backgroundTime = Date().time

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel =
                NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH)
            with(NotificationManagerCompat.from(this)) {
                createNotificationChannel(channel)
            }
        }
        val notification: Notification =
            buildNotification(isRecording = viewModel.isRecording)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            ServiceCompat.startForeground(
                this,
                ONGOING_NOTIFICATION_ID,
                notification,
                FOREGROUND_SERVICE_TYPE_LOCATION or FOREGROUND_SERVICE_TYPE_CAMERA
            )
        } else
            ServiceCompat.startForeground(
                this,
                ONGOING_NOTIFICATION_ID,
                notification,
                FOREGROUND_SERVICE_TYPE_LOCATION
            )
        isItHasNotification = true
    }

    override fun onDestroy() {
        viewModel.setBackgroundAnalysisAlive(false)
//        Log.d(TAG, "service onDestroy")
        pendingActions.clear()
        stopForeground()
        viewModel.stopCamera()
        val duration = Date().time - startTime
        dangerPlayer.release()
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder {
        super.onBind(intent)
//        Log.d(TAG, "service onBind")
        return recordingServiceBinder
    }
}