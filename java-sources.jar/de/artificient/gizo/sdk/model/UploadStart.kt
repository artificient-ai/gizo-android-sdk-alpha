package de.artificient.gizo.sdk.model

data class UploadStart(val fileManagerId: Long)