package de.artificient.gizo.sdk.model

data class Config(
    val aspectRatio: String? = null,
    val chunkSize: Int? = null,
    val tolerance: Int? = null,
    val stackSize: Int? = null,
    val dataMobileLimit: Int? = null,
    val dataRoamingLimit: Int? = null,
    val showDrivingPage: Boolean? = null,
    val showRankingPage: Boolean? = null,
    val showChallenge: Boolean? = null,
    val onlyRecordDrive: Boolean? = null,
    val isMobileDataEnabled: Boolean? = null,
    val isRoamingDataEnabled: Boolean? = null,
)