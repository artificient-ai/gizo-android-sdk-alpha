package de.artificient.gizo.sdk.upload

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import kotlin.reflect.KClass
import java.lang.reflect.Constructor

private const val WORKER_CLASS_NAME = "RouterWorkerDelegateClassName"

fun KClass<out CoroutineWorker>.delegatedData() =
    Data.Builder()
        .putString(WORKER_CLASS_NAME, qualifiedName)
        .build()

class DelegatingWorker(
    appContext: Context,
    workerParams: WorkerParameters,
) : CoroutineWorker(appContext, workerParams) {

    private val workerClassName =
        workerParams.inputData.getString(WORKER_CLASS_NAME) ?: ""

    private val delegateWorker: CoroutineWorker = try {
        val workerClass = Class.forName(workerClassName).kotlin
        val constructor = workerClass.constructors.find { it.parameters.size == 2 }
        constructor?.call(appContext, workerParams) as? CoroutineWorker
            ?: throw IllegalArgumentException("Invalid worker class")
    } catch (e: Exception) {
        throw IllegalArgumentException("Unable to find appropriate worker", e)
    }

    override suspend fun getForegroundInfo(): ForegroundInfo =
        delegateWorker.getForegroundInfo()

    override suspend fun doWork(): Result =
        delegateWorker.doWork()
}