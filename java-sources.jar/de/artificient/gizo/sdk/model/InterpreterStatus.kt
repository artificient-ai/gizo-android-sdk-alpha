package de.artificient.gizo.sdk.model

/**
 * Load Model status
 *
 * It will show [de.artificient.gizo.sdk.GizoApp.loadModel] status.
 *
 * @see [InterpreterStatus.NOT_LOADED]
 * @see [InterpreterStatus.LOADING]
 * @see [InterpreterStatus.LOADED]
 * @see [InterpreterStatus.FAILED]
 *
 */
enum class InterpreterStatus {
    /**
     * Not Loaded when [de.artificient.gizo.sdk.GizoApp.loadModel] not called
     */
    NOT_LOADED,

    /**
     * Loading when model is loading
     *
     */
    LOADING,

    /**
     * Loaded when model is successfully loaded
     *
     */
    LOADED,

    /**
     * Failed when model loading is failed check [de.artificient.gizo.sdk.setting.GizoAnalysisSettings]
     *
     */
    FAILED
}