package de.artificient.gizo.sdk.model

data class UploadChunks(
    val id: Long = 0,
    val mergeStatus: Boolean? = false,
    val uploadPercent: Int = 0,
)
