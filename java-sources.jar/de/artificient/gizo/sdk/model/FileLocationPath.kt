package de.artificient.gizo.sdk.model

/**
 * File location path
 *
 * Indicating that where the data should be saved to a file.
 *
 * @see [FileLocationPath.CACHE]
 * @see [FileLocationPath.DOWNLOAD]
 */
enum class FileLocationPath {
    /**
     * Cache for app cache directory
     *
     * use [android.content.Context.getExternalCacheDirs] as save path
     */
    CACHE,

    /**
     * Download for external download folder
     *
     * use [android.os.Environment.getExternalStoragePublicDirectory] with [android.os.Environment.DIRECTORY_DOWNLOADS] plus [de.artificient.gizo.sdk.setting.GizoAppOptions.folderName] as save path
     */
    DOWNLOAD
}