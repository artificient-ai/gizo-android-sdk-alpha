package de.artificient.gizo.sdk.autostart

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import de.artificient.gizo.sdk.Gizo
import de.artificient.gizo.sdk.GizoAppOptionsDelegate
import java.io.File
import java.io.FileWriter
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

internal class AlarmScheduler {

    private val defaultInterval = 5 * 60 * 1000L // Default interval: 5 minute (in milliseconds)
//    private val intervalFileName = "alarm_interval.txt"
    val options = Gizo.options
    val optionsDelegate = GizoAppOptionsDelegate(options)
    // Schedule exact repeating alarm with interval
    fun scheduleExactAlarm(context: Context) {
        if (options.autoStart) {
//            logToFile(context, "INFO", "Attempting to schedule exact alarm")

            try {
                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
                if (alarmManager == null) {
//                    logToFile(context, "ERROR", "AlarmManager is null, unable to schedule alarm")
                    return
                } else {
//                    logToFile(context, "INFO", "AlarmManager obtained successfully")
                }

                val pendingIntent = getAlarmPendingIntent(context)
                alarmManager.cancel(pendingIntent)
//                logToFile(context, "INFO", "Existing alarms canceled if any")

                val interval = defaultInterval
//                logToFile(context, "INFO", "Using interval: $interval ms")

                val triggerTime = System.currentTimeMillis() + interval
//                logToFile(context, "INFO", "Trigger time calculated: $triggerTime")

                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerTime,
                    pendingIntent
                )
//                logToFile(
//                    context,
//                    "INFO",
//                    "Alarm scheduled successfully with setExactAndAllowWhileIdle"
//                )

            } catch (e: Exception) {
//                logToFile(context, "ERROR", "Failed to schedule exact alarm: ${e.localizedMessage}")
                e.printStackTrace()
            }
        }
    }

//    fun logToFile(context: Context, tag: String, description: String) {
//        // Define the file path and name
//        val fileName = "alarm_scheduler.txt" // Log file name
//        val timeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
//
//        var directory = context.externalCacheDirs.firstOrNull()
//        val logDir = File(directory!!.absolutePath.toString(), "/Gizo")
//        if (!logDir.exists()) {
//            logDir.mkdirs() // Create directory if it doesn't exist
//        }
//
//        val logFile = File(logDir, fileName)
//        try {
//            if (!logFile.exists()) {
//                logFile.createNewFile() // Create file if it doesn't exist
//            }
//
//            // Prepare the log message
//            val currentTime = timeFormat.format(Date())
//            val logMessage = "$currentTime [$tag]: $description\n"
//
//            // Write the log message to the file
//            val fileWriter = FileWriter(logFile, true) // 'true' means append mode
//            fileWriter.append(logMessage)
//            fileWriter.flush()
//            fileWriter.close()
//
//        } catch (e: IOException) {
//            // Handle errors
//            e.printStackTrace()
//        }
//    }

//    // Read the interval from the cache file, create it if it doesn't exist
//    private fun readIntervalFromGizoFolder(context: Context): Long {
//        // Use the cache directory instead of Downloads
//        var directory = context.externalCacheDirs.firstOrNull()
//        val gizoFolder = File(directory!!.absolutePath.toString(), "/Gizo")
//
//        if (!gizoFolder.exists()) {
//            gizoFolder.mkdirs() // Create Gizo folder if it doesn't exist
//        }
//
//        val intervalFile = File(gizoFolder, intervalFileName)
//
//        return if (intervalFile.exists()) {
//            try {
//                val intervalString = intervalFile.readText()
//                val interval = intervalString.toLongOrNull()
//
//                if (interval != null) {
//                    interval
//                } else {
//                    // Show Toast if parsing fails
//                    Toast.makeText(context, "Invalid interval format, using default", Toast.LENGTH_LONG).show()
//                    defaultInterval
//                }
//            } catch (e: Exception) {
//                e.printStackTrace()
//                // Show Toast for any other exception
//                Toast.makeText(context, "Error reading interval file, using default", Toast.LENGTH_LONG).show()
//                defaultInterval
//            }
//        } else {
//            // If file doesn't exist, create it with default interval
//            try {
//                intervalFile.writeText(defaultInterval.toString())
//            } catch (e: Exception) {
//                e.printStackTrace()
//                Toast.makeText(context, "Error creating interval file, using default", Toast.LENGTH_LONG).show()
//            }
//            defaultInterval
//        }
//    }

    // Cancel an existing alarm
    fun cancelAlarm(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pendingIntent = getAlarmPendingIntent(context)

        // Cancel the pending intent if exists
        alarmManager.cancel(pendingIntent)
    }

    // Helper function to create the PendingIntent
    private fun getAlarmPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, LocationBroadcastReceiver::class.java)
        return PendingIntent.getBroadcast(
            context,
            1211213,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}