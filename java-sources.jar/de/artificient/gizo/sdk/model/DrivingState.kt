package de.artificient.gizo.sdk.model

sealed class DrivingState {
    object Camera : DrivingState()
    object NoCamera : DrivingState()
}