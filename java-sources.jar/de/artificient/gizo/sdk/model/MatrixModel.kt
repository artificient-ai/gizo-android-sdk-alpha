package de.artificient.gizo.sdk.model

/**
 * A data class that represents a matrix model with three strings.
 *
 * @property first the first string in the matrix model
 * @property second the second string in the matrix model
 * @property third the third string in the matrix model
 */
internal data class MatrixModel(
    val first: String,
    val second: String,
    val third: String,
)