package de.artificient.gizo.sdk.model

/**
 * Represents an activity recognized by the system, including the type of activity and its transition state.
 *
 * @property userActivity The type of user activity recognized, as defined by [UserActivityType].
 * @property transition The transition state of the activity, as defined by [UserActivityTransitionType].
 */
data class UserActivity(
    val userActivity: UserActivityType? = null,
    val transition: UserActivityTransitionType? = null
)