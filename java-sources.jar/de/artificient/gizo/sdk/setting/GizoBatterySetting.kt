package de.artificient.gizo.sdk.setting

import de.artificient.gizo.sdk.model.FileLocationPath


/**
 * Gizo battery setting refer to the configuration and management options related to the device’s battery usage and performance.
 *
 * These settings allow users to monitor and control the battery usage of their mobile devices.
 *
 * @property checkBattery To allow to check the battery status or not.
 * @property lowBatteryLimit The minimum percentage of battery charge that Analysis options can be implemented.
 * @property lowBatteryStop The minimum percentage of battery charge that Recording video can be implemented.
 * @property interval A loop of time for getting battery status in 1 second.
 * @property checkThermal whether the SDK should monitor the device's battery state.
 * @property checkTemperature whether the SDK should monitor the device's temperature.
 * @property saveCsvFile Specifies whether to save battery and thermal data to a CSV file.
 * @property fileLocation Defines the location where the CSV file will be saved.
 * @property saveDataTimerPeriod Sets the period in milliseconds for saving data to the CSV file.
 *  *
 * @constructor Create empty Gizo battery setting
 */
class GizoBatterySetting private constructor(
    val checkBattery: Boolean,
    val saveCsvFile: Boolean,
    val checkThermal: Boolean,
    val checkTemperature: Boolean,
    val fileLocation: FileLocationPath,
    val lowBatteryLimit: Float,
    val lowBatteryStop: Float,
    val interval: Long,
    val saveDataTimerPeriod: Long,
) {

    /**
     * Use it to regenerate Builder from current options
     *
     * @return
     */
    fun toBuilder(): Builder = Builder().apply {
        checkBattery(checkBattery)
        checkThermal(checkThermal)
        checkTemperature(checkTemperature)
        lowBatteryLimit(lowBatteryLimit)
        lowBatteryStop(lowBatteryStop)
        interval(interval)
        saveCsvFile(saveCsvFile)
        fileLocation(fileLocation)
        saveDataTimerPeriod(saveDataTimerPeriod)
    }

    /**
     * Builder
     *
     * @constructor Create [GizoBatterySetting] instance.
     */
    class Builder() {
        private var checkBattery: Boolean = false
        private var checkThermal: Boolean = false
        private var checkTemperature: Boolean = false
        private var lowBatteryLimit: Float = 25f
        private var lowBatteryStop: Float = 15f
        private var interval: Long = 5000L
        private var saveCsvFile: Boolean = false
        private var fileLocation: FileLocationPath = FileLocationPath.CACHE
        private var saveDataTimerPeriod: Long = 1000L

        /**
         * Check battery is allow to check the battery status or not.
         *
         * @param checkBattery
         */
        fun checkBattery(checkBattery: Boolean = false) =
            apply { this.checkBattery = checkBattery }


        /**
         * Low battery limit is minimum percentage of battery charge that analysis options can be implemented.
         *
         * @param lowBatteryLimit
         */
        fun lowBatteryLimit(lowBatteryLimit: Float = 25f) =
            apply { this.lowBatteryLimit = lowBatteryLimit }

        /**
         * Low battery stop is minimum percentage of battery charge that recording video can be implemented.
         *
         * @param lowBatteryStop
         */
        fun lowBatteryStop(lowBatteryStop: Float = 15f) =
            apply { this.lowBatteryStop = lowBatteryStop }

        /**
         * Interval is a loop of time for getting battery status in 1 second.
         *
         * @param interval
         */
        fun interval(interval: Long = 5000L) = apply { this.interval = interval }

        /**
         * Configures whether the SDK should monitor the device's thermal state.
         *
         * @param checkThermal Boolean value to enable or disable thermal checks.
         */
        fun checkThermal(checkThermal: Boolean = false) =
            apply { this.checkThermal = checkThermal }

        /**
         * Configures whether the SDK should monitor the device's temperature.
         *
         * @param checkTemperature Boolean value to enable or disable temperature checks.
         */
        fun checkTemperature(checkTemperature: Boolean = false) =
            apply { this.checkTemperature = checkTemperature }

        /**
         * Specifies whether to save battery and thermal data to a CSV file.
         *
         * @param saveCsvFile Boolean value to enable or disable saving data to CSV.
         */
        fun saveCsvFile(saveCsvFile: Boolean = false) =
            apply { this.saveCsvFile = saveCsvFile }

        /**
         * Defines the location where the CSV file will be saved.
         *
         * @param fileLocation The [FileLocationPath] representing the file save location.
         */
        fun fileLocation(fileLocation: FileLocationPath = FileLocationPath.CACHE) =
            apply { this.fileLocation = fileLocation }

        /**
         * Sets the period in milliseconds for saving data to the CSV file.
         *
         * @param saveDataTimerPeriod The time period in milliseconds.
         */
        fun saveDataTimerPeriod(saveDataTimerPeriod: Long = 1000L) =
            apply { this.saveDataTimerPeriod = saveDataTimerPeriod }

        fun build(): GizoBatterySetting {
            return GizoBatterySetting(
                checkBattery = checkBattery,
                checkThermal = checkThermal,
                lowBatteryLimit = lowBatteryLimit,
                lowBatteryStop = lowBatteryStop,
                interval = interval,
                saveCsvFile = saveCsvFile,
                fileLocation = fileLocation,
                checkTemperature = checkTemperature,
                saveDataTimerPeriod = saveDataTimerPeriod,
            )
        }
    }
}