package de.artificient.gizo.sdk.model

internal sealed class RecordingBackgroundEvent {
    data object StopBackgroundRecording : RecordingBackgroundEvent()
}