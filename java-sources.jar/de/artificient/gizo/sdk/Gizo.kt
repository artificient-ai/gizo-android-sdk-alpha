package de.artificient.gizo.sdk

import android.annotation.SuppressLint
import android.content.Context
import de.artificient.gizo.sdk.core.GizoAppImpl
import de.artificient.gizo.sdk.setting.GizoOptions
import de.artificient.gizo.sdk.setting.GizoUploadSetting
import java.io.File
import java.io.FileWriter
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Use it to access and setup [GizoApp]
 *
 * @see [Gizo.app]
 * @see [Gizo.initialize]
 * @see [Gizo.setup]
 */
@SuppressLint("StaticFieldLeak")
object Gizo {

    val app: GizoApp
        get() = GizoAppImpl.getInstance()

    var _context: Context? = null

    val options: GizoOptions
        get() = GizoAppImpl.getInstance().options

    fun initialize(context: Context, options: GizoOptions): GizoInitializationResult {
        try {
            _context = context
            GizoAppImpl.initialize(context = context, options = options)

            return GizoInitializationResult(true, null)
        } catch (e: Exception) {
            return GizoInitializationResult(false, e)
        }

    }

    suspend fun createUser(): Long {
        return GizoAppImpl.createUser()
    }

    suspend fun setUserId(userId: Long): Boolean {
        return GizoAppImpl.setUserId(userId)
    }

    fun setToken(clientId: String, clientSecret: String) {
        app.options.clientId = clientId
        app.options.clientSecret = clientSecret
    }

    fun changeUploadSetting(uploadSetting: GizoUploadSetting) {
        GizoAppImpl.changeUploadSetting(uploadSetting)
    }

    fun changeOptions(options: GizoOptions) {
        GizoAppImpl.changeOptions(options)
    }

}