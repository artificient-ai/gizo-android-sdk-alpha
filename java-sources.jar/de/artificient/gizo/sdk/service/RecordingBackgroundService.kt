package de.artificient.gizo.sdk.service

import android.Manifest
import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationCompat.PRIORITY_HIGH
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.app.TaskStackBuilder
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.flowWithLifecycle
import androidx.lifecycle.lifecycleScope
import de.artificient.gizo.sdk.Gizo
import de.artificient.gizo.sdk.GizoAppOptionsDelegate
import de.artificient.gizo.sdk.autostart.AlarmScheduler
import de.artificient.gizo.sdk.config.GizoCameraSetting
import de.artificient.gizo.sdk.config.GizoNoCameraDefaultSetting
import de.artificient.gizo.sdk.config.GizoNoCameraSetting
import de.artificient.gizo.sdk.core.GizoAnalysisImpl
import de.artificient.gizo.sdk.core.GizoProvider
import de.artificient.gizo.sdk.core.common.util.checkInitialPermissions
import de.artificient.gizo.sdk.core.common.util.getAppIcon
import de.artificient.gizo.sdk.core.common.util.hasPermission
import de.artificient.gizo.sdk.model.DrivingState
import de.artificient.gizo.sdk.model.GizoRecordingType
import de.artificient.gizo.sdk.model.NotificationEvent
import de.artificient.gizo.sdk.model.RecordingBackgroundEvent
import de.artificient.gizo.sdk.model.RecordingState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileWriter
import java.io.IOException
import java.lang.ref.WeakReference
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

internal class RecordingBackgroundService: LifecycleService() {

    companion object {
        private val TAG = RecordingBackgroundService::class.simpleName
        const val ACTION_START = "ACTION_START"
        const val ACTION_DRIVING_YES = "ACTION_DRIVING_YES"
        const val ACTION_DRIVING_NO = "ACTION_DRIVING_NO"
        const val ACTION_RECORDING_NO_CAMERA = "ACTION_RECORDING_NO_CAMERA"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_RECORDING_FULL = "ACTION_RECORDING_FULL"
        const val ACTION_RECORDING_SELECT = "ACTION_RECORDING_SELECT"
        const val CHANNEL_NAME = "background recording service"
        const val CHANNEL_ID = "background_recording_service"

        const val Intent_Recording_Select = "Intent_Recording_Select"
        const val Intent_Action = "Intent_Action"
        const val ONGOING_NOTIFICATION_ID = 2355
        private var serviceInstance: WeakReference<RecordingBackgroundService>? = null

        fun startService(context: Context): Boolean {
//            logToFile(context, TAG ?: "", "Attempting to start service")

            val coroutineScope = CoroutineScope(Dispatchers.IO)

            coroutineScope.launch {
                try {
                    while (!checkInitialPermissions(context)) {
//                        logToFile(context, TAG ?: "", "Waiting for permissions...")
                        delay(5000) // Wait 5 seconds
                    }

//                    logToFile(context, TAG ?: "", "All required permissions granted. Starting service.")

                    if (hasPermissionToStart(context)) {
                        val serviceIntent = Intent(context, RecordingBackgroundService::class.java).apply {
                            action = ACTION_START
                        }
                        ContextCompat.startForegroundService(context, serviceIntent)
//                        Log.d(TAG ?: "", "Service started")
//                        logToFile(context, TAG ?: "", "Service started")
                    }
                } catch (e: Exception) {
                    Log.e(TAG ?: "", "Failed to start service", e)
//                    logToFile(context, TAG ?: "", "Failed to start service: ${e.message}")
                }
            }

            return true
        }

        fun stopService(context: Context) {
//            logToFile(context, TAG!!, "Attempting to stop service")
            try {
                serviceInstance?.get()?.viewModel?.pauseBackgroundRecording()
//                Log.d(TAG ?: "", "Service stopped")
//                logToFile(context, TAG ?: "", "Service stopped")
            } catch (e: Exception) {
                serviceInstance?.get()?.viewModel?.addExceptionError(error = e.message.toString())
                Log.e(TAG ?: "", "Failed to stop service", e)
//                logToFile(context, TAG ?: "", "Failed to stop service: ${e.message}")
            }
        }

        fun changeDrivingState() {
            serviceInstance?.get()?.viewModel?.setDrivingState(DrivingState.NoCamera)
        }

        private fun hasPermissionToStart(context: Context): Boolean {
            val hasPermission = if (Build.VERSION.SDK_INT > Build.VERSION_CODES.TIRAMISU) {
                context.hasPermission(
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION
                )
            } else true

//            Log.d(TAG ?: "", "hasPermissionToStart: $hasPermission")
//            logToFile(context, TAG!!, "Checked permission to start service: $hasPermission")
            return hasPermission
        }

        fun performAction(context: Context, action: String) {
//            logToFile(context, TAG!!, "Performing action: $action")
            try {
                if (hasPermissionToStart(context)) {
                    val serviceIntent = Intent(context, RecordingBackgroundService::class.java).apply {
                        this.action = action
                    }
                    ContextCompat.startForegroundService(context, serviceIntent)
//                    Log.d(TAG ?: "", "Action performed: $action")
//                    logToFile(context, TAG ?: "", "Action performed: $action")
                }
            } catch (e: Exception) {
                Log.e(TAG ?: "", "Failed to perform action: $action", e)
//                logToFile(context, TAG ?: "", "Failed to perform action $action: ${e.message}")
            }
        }

        fun isRunning(context: Context): Boolean {
//            logToFile(context, TAG!!, "Checking if service is running")
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            for (service in manager.getRunningServices(Integer.MAX_VALUE)) {
                if (RecordingBackgroundService::class.java.name == service.service.className && service.foreground) {
//                    Log.d(TAG ?: "", "Service is running")
//                    logToFile(context, TAG ?: "", "Service is running")
                    return true
                }
            }
//            logToFile(context, TAG ?: "", "Service is not running")
            return false
        }

//        fun logToFile(context: Context, tag: String, description: String) {
//            // Define the file path and name
//            val fileName = "recording_background_service.txt" // Log file name
//            val timeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
//
//            var directory = context.externalCacheDirs.firstOrNull()
//            val logDir = File(directory!!.absolutePath.toString(), "/Gizo")
//            if (!logDir.exists()) {
//                logDir.mkdirs() // Create directory if it doesn't exist
//            }
//
//            val logFile = File(logDir, fileName)
//            try {
//                if (!logFile.exists()) {
//                    logFile.createNewFile() // Create file if it doesn't exist
//                }
//
//                // Prepare the log message
//                val currentTime = timeFormat.format(Date())
//                val logMessage = "$currentTime [$tag]: $description\n"
//
//                // Write the log message to the file
//                val fileWriter = FileWriter(logFile, true) // 'true' means append mode
//                fileWriter.append(logMessage)
//                fileWriter.flush()
//                fileWriter.close()
//
//            } catch (e: IOException) {
//                // Handle errors
//                e.printStackTrace()
//            }
//        }
    }

    private var notificationCheckAliveJob: Job? = null

    private var currentNotificationEvent: NotificationEvent = NotificationEvent.BackgroundDefault

    private var isStartedAsForeground = false

    private val viewModel: GizoAnalysisImpl by lazy {
        GizoProvider.provideGizoAnalysis(applicationContext, optionsDelegate) as GizoAnalysisImpl
    }

    private var lastRecordingMode: RecordingState? = null

    val options = Gizo.options
    val optionsDelegate = GizoAppOptionsDelegate(options = options)

    override fun onCreate() {
        try {
//            logToFile(applicationContext, TAG ?: "", "Service onCreate called")
//            Log.d(TAG ?: "", "onCreate")
            super.onCreate()

//            logToFile(applicationContext, TAG ?: "", "Canceling and scheduling exact alarm")
            AlarmScheduler().cancelAlarm(this)
            AlarmScheduler().scheduleExactAlarm(this)
            serviceInstance = WeakReference(this)

//            logToFile(applicationContext, TAG ?: "", "Starting analytic trace for background running")
//            analytic.startTrace(AnalyticManager.Event.RECORDING_BACKGROUND_RUNNING)
            viewModel.initialViewModel()

            when (viewModel.currentState) {
                DrivingState.Camera -> {
//                    viewModel.startRecording(type = GizoRecordingType.CAMERA, GizoCameraSetting)
                }
                DrivingState.NoCamera -> {
                    viewModel.startRecording(type = GizoRecordingType.NO_CAMERA, GizoNoCameraDefaultSetting())
                }
            }

            viewModel.registerGeofencing()
//            viewModel.bindMapNavigation(this)
            viewModel.stillPauseStart {
//                logToFile(applicationContext, TAG ?: "", "State changed to STILL")
                viewModel.changeRecordState(RecordingState.STILL)
            }

            lifecycleScope.launch {
                viewModel.recordingState.flowWithLifecycle(lifecycle).collect {

                    if (lastRecordingMode != it) {
                        lastRecordingMode?.let { last ->
                        }
                    }
                    lastRecordingMode = it
                }
            }

            lifecycleScope.launch {
                viewModel.notificationEvent.flowWithLifecycle(lifecycle).collect { event ->
//                    logToFile(applicationContext, TAG ?: "", "Notification event received: $event")
                    updateNotificationEvent(event)
                }
            }

            lifecycleScope.launch {
                viewModel.recordingBackgroundEvent.flowWithLifecycle(lifecycle).collect { event ->
//                    logToFile(applicationContext, TAG ?: "", "Recording background event: $event")
//                    Log.d(TAG ?: "", "recordingBackgroundEvent $event")
                    when (event) {
                        RecordingBackgroundEvent.StopBackgroundRecording -> {
//                            logToFile(applicationContext, TAG ?: "", "Stopping foreground service and self")
                            ServiceCompat.stopForeground(
                                this@RecordingBackgroundService,
                                ServiceCompat.STOP_FOREGROUND_REMOVE
                            )
                            this@RecordingBackgroundService.stopSelf()
                        }
                    }
                }
            }
        } catch (e: Exception) {
//            logToFile(applicationContext, TAG ?: "", "Error in onCreate: ${e.message}")
            viewModel.addExceptionError(error = e.message.toString())
        }
    }

    private fun updateNotificationEvent(event: NotificationEvent) {
        currentNotificationEvent = event
        when (event) {
            is NotificationEvent.BackgroundDefault -> {
                updateNotification(haveCancelAction = true)
            }

            is NotificationEvent.BackgroundStill -> {
                updateNotification(haveCancelAction = true)
            }

            is NotificationEvent.BackgroundNoCamera -> {
                updateNotification(
                    haveCancelAction = true,
                    noCameraAction = true
                )
            }

            is NotificationEvent.RecordingFullQuestion -> {
                updateNotification(
                    title = "It seems you are in a vehicle.",
                    content = "Do you want recording video?",
                    haveRecordingWithCamera = true,
                    haveRecordingWithoutCamera = true,
                    needRecordingPermission = event.needPermission,
                    onlyAlertOnce = false
                )
            }

            is NotificationEvent.InVehicleQuestion -> {
                updateNotification(
                    title = "It seems you are in a vehicle.",
                    content = " Are you driving?",
                    haveDrivingYesAction = true,
                    needRecordingPermission = event.needPermission,
                    haveDrivingNoAction = true,
                    onlyAlertOnce = false
                )

            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
//            logToFile(applicationContext, TAG ?: "", "onStartCommand action: ${intent?.action}")
            super.onStartCommand(intent, flags, startId)

            if (checkInitialPermissions(this).not()){
                stopService(this)
            }

            when (intent?.action) {
                ACTION_START -> {
//                    logToFile(applicationContext, TAG ?: "", "Action START received")
                    if (options.autoStart && !isStartedAsForeground) {
                        startRunningInForeground()
                    }
                }

                ACTION_DRIVING_YES -> {
//                    logToFile(applicationContext, TAG ?: "", "Action DRIVING_YES received")
                    viewModel.actionDrivingYes()
                }

                ACTION_DRIVING_NO -> {
//                    logToFile(applicationContext, TAG ?: "", "Action DRIVING_NO received")
                    viewModel.notifyInVehicleNotifyed()
                }

                ACTION_RECORDING_NO_CAMERA -> {
//                    logToFile(applicationContext, TAG ?: "", "Action RECORDING_NO_CAMERA received")
                    viewModel.notifyAcceptRecordingNoCamera()
                }

                ACTION_RECORDING_FULL -> {
//                    logToFile(applicationContext, TAG ?: "", "Action RECORDING_FULL received")
                    viewModel.notifyedRecordingFull()
                }

                ACTION_RECORDING_SELECT -> {
                    viewModel.notifyedRecordingSelect()
                }

                ACTION_STOP -> {
//                    logToFile(applicationContext, TAG ?: "", "Action STOP received")
                    viewModel.changeRecordState(RecordingState.STILL)
                }

//                else -> logToFile(applicationContext, TAG ?: "", "Unknown action received")
            }

            return START_STICKY
        } catch (e: Exception) {
//            logToFile(applicationContext, TAG ?: "", "Error in onStartCommand: ${e.message}")
            viewModel.addExceptionError(error = e.message.toString())
            return START_STICKY
        }
    }


    @SuppressLint("MissingPermission")
    private fun updateNotification(
        title: String = "GIZO Analysis",
        content: String = "Background activity analysis",
        onlyAlertOnce: Boolean = true,
        noCameraAction: Boolean = false,
        haveDrivingYesAction: Boolean = false,
        haveDrivingNoAction: Boolean = false,
        haveRecordingWithCamera: Boolean = false,
        haveRecordingWithoutCamera: Boolean = false,
        needRecordingPermission: Boolean = false,
        haveCancelAction: Boolean = false,
    ) {
        try {
            val notification = buildNotification(
                title = title,
                content = content,
                noCameraAction = noCameraAction,
                onlyAlertOnce = onlyAlertOnce,
                haveDrivingYesAction = haveDrivingYesAction,
                haveDrivingNoAction = haveDrivingNoAction,
                haveRecordingWithCamera = haveRecordingWithCamera,
                haveRecordingWithoutCamera = haveRecordingWithoutCamera,
                needRecordingPermission = needRecordingPermission,
                haveCancelAction = haveCancelAction,
            )
            with(NotificationManagerCompat.from(this)) {
                notify(ONGOING_NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
//            logToFile(this, "NotificationError", "Failed to update notification: ${e.message}")
            Log.e("NotificationError", "Failed to update notification", e)
        }
    }

    private fun isNotificationVisible(): Boolean {
        return try {
            val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val notifications = notificationManager.activeNotifications
            for (notification in notifications) {
                if (notification.id == ONGOING_NOTIFICATION_ID) {
//                    logToFile(this, "NotificationCheck", "Notification is visible.")
                    return true
                }
            }
//            logToFile(this, "NotificationCheck", "Notification is not visible.")
            false
        } catch (e: Exception) {
//            logToFile(this, "NotificationError", "Failed to check notification visibility: ${e.message}")
            Log.e("NotificationError", "Error checking notification visibility", e)
            false
        }
    }

    private fun buildNotification(
        title: String = "GIZO Analysis",
        content: String = "Background activity analysis",
        onlyAlertOnce: Boolean = true,
        noCameraAction: Boolean = false,
        haveDrivingYesAction: Boolean = false,
        haveDrivingNoAction: Boolean = false,
        haveRecordingWithCamera: Boolean = false,
        haveRecordingWithoutCamera: Boolean = false,
        needRecordingPermission: Boolean = false,
        haveCancelAction: Boolean = false,
    ): Notification {
        val tag = "buildNotification"
        val context = this
//        logToFile(context, tag, "Building notification with title: $title and content: $content")

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(getAppIcon(this))
            .setBadgeIconType(NotificationCompat.BADGE_ICON_SMALL)
//            .setContentIntent(
//                if (noCameraAction) {
//                    logToFile(context, tag, "Setting noCameraAction content intent")
//                    getPendingActivity(
//                        parent = Class.forName("de.artificient.gizo.ui.MainActivity"),
//                        activity = RecordingNoCameraActivity::class.java
//                    )
//                } else {
//                    logToFile(context, tag, "Setting default content intent")
//                    getPendingActivity(activity = Class.forName("de.artificient.gizo.ui.SplashActivity"))
//                }
//            )
            .setPriority(PRIORITY_HIGH)
            .setOnlyAlertOnce(onlyAlertOnce)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setAutoCancel(false)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)

        if (haveDrivingYesAction) {
//            logToFile(context, tag, "Adding Driving Yes action")
            builder.addAction(
                0,
                "Yes",
                if (!needRecordingPermission) getPending(ACTION_DRIVING_YES)
                else getPendingActivity(
                    activity = Class.forName("de.artificient.gizo.ui.MainActivity"),
                    extraBundle = bundleOf(
                        "initialScreen" to 1,
                        Intent_Recording_Select to true,
                        Intent_Action to ACTION_RECORDING_SELECT
                    )
                )
            )
        }

        if (haveDrivingNoAction) {
//            logToFile(context, tag, "Adding Driving No action")
            builder.addAction(
                0,
                "No",
                getPending(ACTION_DRIVING_NO)
            )
        }

        if (haveRecordingWithCamera) {
//            logToFile(context, tag, "Adding Recording With Camera action")
//            builder.addAction(
//                0,
//                "Yes",
//                if (!needRecordingPermission) getPendingActivity(
//                    parent = Class.forName("de.artificient.gizo.ui.MainActivity"),
//                    activity = RecordingCameraActivity::class.java
//                ) else getPendingActivity(
//                    activity = Class.forName("de.artificient.gizo.ui.MainActivity"),
//                    extraBundle = bundleOf(
//                        "initialScreen" to 1,
//                        Intent_Recording_Select to true,
//                        Intent_Action to ACTION_RECORDING_SELECT
//                    )
//                )
//            )
        }

        if (haveRecordingWithoutCamera) {
//            logToFile(context, tag, "Adding Recording Without Camera action")
            builder.addAction(
                0,
                "NO",
                getPending(ACTION_RECORDING_NO_CAMERA)
            )
        }

        if (haveCancelAction) {
//            logToFile(context, tag, "Adding Cancel action")
            builder.addAction(
                0,
                "Stop",
                getPending(ACTION_STOP)
            )
        }

//        logToFile(context, tag, "Notification built successfully")
        return builder.build()
    }

    private fun getPending(intentAction: String): PendingIntent {
        val recordingIntent = Intent(this, RecordingBackgroundService::class.java).apply {
            action = intentAction
        }
        val recordingPendingIntent: PendingIntent =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                PendingIntent.getForegroundService(
                    this,
                    0,
                    recordingIntent,
                    PendingIntent.FLAG_IMMUTABLE
                )
            } else {
                PendingIntent.getService(this, 0, recordingIntent, PendingIntent.FLAG_IMMUTABLE)
            }
        return recordingPendingIntent
    }

    private fun getPendingActivity(
        parent: Class<*>? = null, activity: Class<*>,
        extraBundle: Bundle = bundleOf(),
    ): PendingIntent? {

        if (parent == null) {
            val notifyIntent = Intent(this, activity).apply {
                putExtras(extraBundle)
            }
            return PendingIntent.getActivity(
                this, 0, notifyIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

        } else {
            val parentStack = TaskStackBuilder.create(this)
            parentStack.addParentStack(parent)
            parentStack.addNextIntent(Intent(this, activity).apply {
                putExtras(extraBundle)
            })
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                parentStack.getPendingIntent(0, PendingIntent.FLAG_IMMUTABLE)
            } else {
                parentStack.getPendingIntent(0, 0)
            }
        }
    }

    private fun startRunningInForeground() {
        val tag = "startRunningInForeground"
        val context = this
        try {
//            logToFile(context, tag, "Starting foreground service setup")

//            Log.d(TAG ?: "", "startRunningInForeground")
//            logToFile(context, tag, "Creating notification channel")

            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH)
            with(NotificationManagerCompat.from(this)) {
                createNotificationChannel(channel)
            }
//            logToFile(context, tag, "Notification channel created")

//            logToFile(context, tag, "Building notification")
            val notification: Notification = buildNotification(haveCancelAction = true)
//            logToFile(context, tag, "Notification built successfully")

//            logToFile(context, tag, "Starting service in the foreground")
            ServiceCompat.startForeground(
                this,
                ONGOING_NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            )
//            logToFile(context, tag, "Foreground service started successfully")

            isStartedAsForeground = true
//            logToFile(context, tag, "Service marked as foreground started")
//
//            logToFile(context, tag, "Calling notificationCheckAlive")
            notificationCheckAlive()
//            logToFile(context, tag, "notificationCheckAlive executed successfully")

        } catch (e: Exception) {
//            logToFile(context, tag, "Error occurred: ${e.message}")
//            Log.e(TAG ?: "", "Error starting foreground service", e)
//
//            logToFile(context, tag, "Stopping foreground service due to error")
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
//            logToFile(context, tag, "Foreground service stopped")
        }
    }

    private fun notificationCheckAlive() {
        notificationCheckAliveJob?.cancel()
        notificationCheckAliveJob = lifecycleScope.launch {
            delay(5000)
            while (isActive) {
                if (isNotificationVisible().not()) {
                    updateNotificationEvent(currentNotificationEvent)
                }
                delay(1000)
            }
        }
    }

    override fun onDestroy() {
        val tag = "onDestroy"
        try {
//            logToFile(this, tag, "onDestroy called")

//            Log.d(TAG ?: "", "onDestroy")
//            logToFile(this, tag, "Clearing service instance")

            serviceInstance?.clear()
            serviceInstance = null
//            logToFile(this, tag, "Service instance cleared")

            // Log potential ViewModel actions if uncommented
            // logToFile(this, tag, "Changing record state to STILL")
            // viewModel.changeRecordState(RecordingState.STILL)

            // logToFile(this, tag, "Unregistering activity recognition")
            // viewModel.unRegisterActivityRecognition()

//            logToFile(this, tag, "Cancelling notificationCheckAlive job")
            notificationCheckAliveJob?.cancel()

//            logToFile(this, tag, "Cancelling lifecycleScope coroutine context children")
            lifecycleScope.coroutineContext.cancelChildren()

//            logToFile(this, tag, "Stopping foreground service")
            stopForeground(true)

//            logToFile(this, tag, "Stopping analytic trace for background recording")

//            logToFile(this, tag, "Cancelling ongoing notification")
            with(NotificationManagerCompat.from(this)) {
                cancel(ONGOING_NOTIFICATION_ID)
            }

//            logToFile(this, tag, "Resetting isStartedAsForeground flag")
            isStartedAsForeground = false

//            logToFile(this, tag, "Unregistering all sensors")
            viewModel.unRegisterAllSensors()

//            logToFile(this, tag, "Calling super.onDestroy")
            super.onDestroy()

//            logToFile(this, tag, "onDestroy completed successfully")

        } catch (e: Exception) {
//            logToFile(this, tag, "Error in onDestroy: ${e.message}")
            viewModel.addExceptionError(error = e.message.toString())
        }
    }

}