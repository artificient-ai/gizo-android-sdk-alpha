package de.artificient.gizo.sdk.setting

import de.artificient.gizo.sdk.model.FileLocationPath

/**
 * Configuration settings for handling device events within the Gizo SDK.
 * Allows specifying whether device events should be captured, if they should be saved to a CSV file,
 * and the location where these files should be stored.
 *
 * @property allowDeviceEvent Flag indicating whether device events should be captured (true) or not (false).
 * @property saveCsvFile Flag indicating whether to save device events data to a CSV file (true) or not (false).
 */
class GizoPhoneEventSetting private constructor(
    val saveCsvFile: Boolean,
) {

    /**
     * Creates a builder instance for [GizoPhoneEventSetting] with current settings.
     *
     * @return A new [Builder] instance initialized with the current settings of [GizoPhoneEventSetting].
     */
    fun toBuilder(): Builder = Builder().apply {
        saveCsvFile(saveCsvFile)
    }

    /**
     * Builder class for [GizoPhoneEventSetting]. Allows for customizable creation of [GizoPhoneEventSetting] instances.
     */
    class Builder() {
        private var saveCsvFile: Boolean = false

        /**
         * Specifies whether to save device events data to a CSV file.
         *
         * @param saveCsvFile True to save device events data to a CSV file, false otherwise.
         * @return The current [Builder] instance for chaining.
         */
        fun saveCsvFile(saveCsvFile: Boolean = false) =
            apply { this.saveCsvFile = saveCsvFile }

        /**
         * Builds a [GizoPhoneEventSetting] instance with the specified settings.
         *
         * @return A new [GizoPhoneEventSetting] instance.
         */
        fun build(): GizoPhoneEventSetting {
            return GizoPhoneEventSetting(
                saveCsvFile = saveCsvFile,
            )
        }
    }
}