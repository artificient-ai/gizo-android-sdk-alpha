package de.artificient.gizo.sdk.model

/**
 * Enumerates the types of user activities recognized by the system, represented by an integer value.
 *
 * @property action The integer representation of the activity type.
 */
enum class UserActivityType(val action: Int) {
    /**
     * Activity type indicating the user is in a vehicle.
     */
    IN_VEHICLE(0),

    /**
     * Activity type indicating the user is on a bicycle.
     */
    ON_BICYCLE(1),

    /**
     * Activity type indicating the user is on foot.
     */
    ON_FOOT(2),

    /**
     * Activity type indicating the user is still (not moving).
     */
    STILL(3),

    /**
     * Activity type indicating the user is walking.
     */
    WALKING(7),

    /**
     * Activity type indicating the user is running.
     */
    RUNNING(8)
}