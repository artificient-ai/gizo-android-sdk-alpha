package de.artificient.gizo.sdk.config

import de.artificient.gizo.sdk.setting.GizoActiveAppSetting
import de.artificient.gizo.sdk.setting.GizoPhoneEventSetting
import de.artificient.gizo.sdk.setting.GizoGpsSetting
import de.artificient.gizo.sdk.setting.GizoImuSetting
import de.artificient.gizo.sdk.setting.GizoOrientationSetting
import de.artificient.gizo.sdk.setting.GizoActivitySetting
import de.artificient.gizo.sdk.setting.GizoStopRecordingSetting
import de.artificient.gizo.sdk.setting.GizoVideoSetting

interface IGizoConfig {
    val imuSetting: GizoImuSetting
    val gpsSetting: GizoGpsSetting
    val videoSetting: GizoVideoSetting
    val activitySetting: GizoActivitySetting
    val orientationSetting: GizoOrientationSetting
    val phoneEventSetting: GizoPhoneEventSetting
    val activeAppSetting: GizoActiveAppSetting
    val stopRecordingSetting: GizoStopRecordingSetting
}