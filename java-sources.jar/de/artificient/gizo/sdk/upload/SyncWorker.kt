package de.artificient.gizo.sdk.upload

import android.content.Context
import androidx.tracing.traceAsync
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.WorkerParameters
import de.artificient.gizo.sdk.Gizo
import de.artificient.gizo.sdk.GizoAppOptionsDelegate
import de.artificient.gizo.sdk.core.GizoAnalysisImpl
import de.artificient.gizo.sdk.core.GizoProvider
import de.artificient.gizo.sdk.core.data.datasource.IUploadDataSource
import de.artificient.gizo.sdk.core.data.datasource.UploadDataSource
import de.artificient.gizo.sdk.core.data.di.DataProvider.provideUploadDataSource
import de.artificient.gizo.sdk.core.data.util.Synchronizer
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext

internal class SyncWorker(
    var appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams), Synchronizer {

    val options = Gizo.options
    val optionsDelegate = GizoAppOptionsDelegate(options = options)

    private val iUploadDataSource: IUploadDataSource by lazy {
        provideUploadDataSource(appContext, optionsDelegate) as IUploadDataSource
    }
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO // Replace with your dispatcher

    override suspend fun doWork(): Result = withContext(ioDispatcher) {
        traceAsync("Sync", 0) {
            val syncedSuccessfully = awaitAll(
                async { iUploadDataSource.sync() },
            ).all { it }

            if (syncedSuccessfully) {
                Result.success()
            } else {
                Result.retry()
            }
        }
    }

    override suspend fun getForegroundInfo(): ForegroundInfo =
        appContext.syncForegroundInfo()

    override suspend fun uploadTrips(): Boolean {
        iUploadDataSource.statusAndUpload()
        return false
    }

    companion object {
        fun builder() = OneTimeWorkRequestBuilder<DelegatingWorker>()
            .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
            .setConstraints(SyncConstraints)
            .setInputData(SyncWorker::class.delegatedData())
    }
}

