package de.artificient.gizo.sdk.model

/**
 * Analysis tensorflow delegate type
 *
 * @see [de.artificient.gizo.sdk.setting.GizoAnalysisSettings]
 *
 * @see [AnalysisDelegateType.CPU]
 * @see [AnalysisDelegateType.GPU]
 * @see [AnalysisDelegateType.NnApi]
 * @see [AnalysisDelegateType.Auto]
 */
enum class AnalysisDelegateType{
    /**
     * Cpu it will use default tensorflow delegate
     *
     */
    CPU,

    /**
     * Gpu will use [org.tensorflow.lite.gpu.GpuDelegate]
     *
     */
    GPU,

    /**
     * Nnapi it will use [org.tensorflow.lite.nnapi.NnApiDelegate]
     *
     */
    NnApi,

    /**
     * Auto it will chose best supported delegate
     */
    Auto
}