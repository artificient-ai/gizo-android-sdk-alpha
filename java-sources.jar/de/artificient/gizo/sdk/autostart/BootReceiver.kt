package de.artificient.gizo.sdk.autostart

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import de.artificient.gizo.sdk.Gizo
import de.artificient.gizo.sdk.GizoAppOptionsDelegate
import de.artificient.gizo.sdk.core.common.Constants
import de.artificient.gizo.sdk.service.RecordingBackgroundService
import de.artificient.gizo.sdk.setting.GizoOptions
import java.io.File
import java.io.FileWriter
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

internal class BootReceiver : BroadcastReceiver() {

    val options = Gizo.options
    val optionsDelegate = GizoAppOptionsDelegate(options)

    override fun onReceive(context: Context, intent: Intent) {
//        logToFile(context, "onReceive", "Received intent: ${intent.action}")

        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
//            logToFile(context, "onReceive", "Boot completed detected")

            val sharedPreferences = context.getSharedPreferences("GizoPreferences", Context.MODE_PRIVATE)
            val license = sharedPreferences.getString("license", "")
            val logToConsole = sharedPreferences.getBoolean("logToConsole", false)
            val autoStart = sharedPreferences.getBoolean("autoStart", false)
            val autoStop = sharedPreferences.getBoolean("autoStop", false)

//            logToFile(context, "onReceive", "Preferences loaded: license=$license, logToConsole=$logToConsole, autoStart=$autoStart, autoStop=$autoStop")

            val result = Gizo.initialize(
                context,
                GizoOptions.Builder(license = license ?: "")
                    .logToConsole(logToConsole)
                    .autoStop(autoStop)
                    .autoStart(autoStart)
                    .build()
            )

            if (result.isSuccessful) {
//                logToFile(context, "onReceive", "SDK initialization successful")
//                print("[SDK]: Initialization successful")
            } else {
//                logToFile(context, "onReceive", "SDK initialization failed: ${result.failure?.message}")
//                print("[SDK]: Initialization failed, reason: ${result.failure?.message}")
            }

            if (Constants.licenseType != -1) {
                if (autoStart) {
                    if (!RecordingBackgroundService.isRunning(context.applicationContext)) {
//                        logToFile(context, "onReceive", "Starting RecordingBackgroundService")
                        RecordingBackgroundService.startService(context.applicationContext)
                    }
                }
            }
        }
    }

//    fun logToFile(context: Context, tag: String, description: String) {
//        // Define the file path and name
//        val fileName = "Boot_Receiver.txt" // Log file name
//        val timeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
//
//        var directory = context.externalCacheDirs.firstOrNull()
//        val logDir = File(directory!!.absolutePath.toString(), "/Gizo")
//        if (!logDir.exists()) {
//            logDir.mkdirs() // Create directory if it doesn't exist
//        }
//
//        val logFile = File(logDir, fileName)
//        try {
//            if (!logFile.exists()) {
//                logFile.createNewFile() // Create file if it doesn't exist
//            }
//
//            // Prepare the log message
//            val currentTime = timeFormat.format(Date())
//            val logMessage = "$currentTime [$tag]: $description\n"
//
//            // Write the log message to the file
//            val fileWriter = FileWriter(logFile, true) // 'true' means append mode
//            fileWriter.append(logMessage)
//            fileWriter.flush()
//            fileWriter.close()
//
//        } catch (e: IOException) {
//            // Handle errors
//            e.printStackTrace()
//        }
//    }
}