package de.artificient.gizo.sdk.setting

import de.artificient.gizo.sdk.model.FileLocationPath

class GizoActiveAppSetting private constructor(
    val allowActiveApp: Boolean,
    val saveCsvFile: Boolean,
) {

    fun toBuilder(): Builder = Builder().apply {
        allowActiveApp(allowActiveApp)
        saveCsvFile(saveCsvFile)
    }

    class Builder() {
        private var allowActiveApp: Boolean = false
        private var saveCsvFile: Boolean = false

        fun allowActiveApp(allowActiveApp: Boolean = false) =
            apply { this.allowActiveApp = allowActiveApp }

        fun saveCsvFile(saveCsvFile: Boolean = false) =
            apply { this.saveCsvFile = saveCsvFile }

        fun build(): GizoActiveAppSetting {
            return GizoActiveAppSetting(
                allowActiveApp = allowActiveApp,
                saveCsvFile = saveCsvFile,
            )
        }
    }
}