package de.artificient.gizo.sdk.model

data class Trip(
    val id: Long = 0,
    val score: Double,
    var isCompleted: Boolean = false,
    val createDate: String? = "",
    val createMonth: String? = "",
    val fileAddress: String? = null,
    val uploadPercent: UploadChunks = UploadChunks(uploadPercent = 0),
    val originLat: String? = "",
    val originLng: String? = "",
    val destinationLat: String? = "",
    val destinationLng: String? = "",
    val origin: String? = "",
    val destination: String? = "",
    val originAddress: String? = "",
    val originPostalCode: String? = "",
    val originLocality: String? = "",
    val originPlace: String? = "",
    val destinationAddress: String? = "",
    val destinationPostalCode: String? = "",
    val destinationLocality: String? = "",
    val destinationPlace: String? = "",
    val startDateTime: String? = "",
    val endDateTime: String? = "",
    val duration: String? = "",
    val isLocalTrip: Boolean = false,
    val isPrepareToShow: Boolean = true,
    val transportationType: TransportationType?,
    val iAmDriver: Boolean?,
    val hasAccident: Boolean?
)

