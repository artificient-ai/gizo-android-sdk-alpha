package de.artificient.gizo.sdk.config

import androidx.camera.video.Quality
import de.artificient.gizo.sdk.model.GizoRecordingType
import de.artificient.gizo.sdk.setting.GizoActiveAppSetting
import de.artificient.gizo.sdk.setting.GizoActivitySetting
import de.artificient.gizo.sdk.setting.GizoGpsSetting
import de.artificient.gizo.sdk.setting.GizoImuSetting
import de.artificient.gizo.sdk.setting.GizoOrientationSetting
import de.artificient.gizo.sdk.setting.GizoPhoneEventSetting
import de.artificient.gizo.sdk.setting.GizoStopRecordingSetting
import de.artificient.gizo.sdk.setting.GizoVideoSetting

internal class GizoCameraDefaultSetting : IGizoConfig {

        override val imuSetting = GizoImuSetting.Builder()
            .allowAccelerationSensor(true)
            .allowMagneticSensor(true)
            .allowGyroscopeSensor(true)
            .saveDataTimerPeriod(50)
            .saveCsvFile(true)
            .build()

    override val gpsSetting = GizoGpsSetting.Builder()
                .allowGps(true)
                .interval(1000)
                .saveCsvFile(true)
                .build()

    override val videoSetting = GizoVideoSetting.Builder()
            .allowRecording(true)
            .quality(Quality.HD)
            .ai(false)
            .build()

    override val activitySetting = GizoActivitySetting.Builder()
                .allowActivity(true)
                .saveCsvFile(true)
                .build()

    override val orientationSetting = GizoOrientationSetting.Builder()
            .allowGravitySensor(true)
            .build()

    override val phoneEventSetting = GizoPhoneEventSetting.Builder()
            .saveCsvFile(true)
            .build()

    override val stopRecordingSetting = GizoStopRecordingSetting.Builder()
            .stopRecordingOnLowBatteryLevel(15)
            .stopAiOnLowBatteryLevel(25)
            .build()

    override val activeAppSetting: GizoActiveAppSetting =
        GizoActiveAppSetting.Builder()
            .allowActiveApp(true)
            .saveCsvFile(true)
            .build()
}

class GizoCameraSetting(
    var ai: Boolean,
    var stopRecordingSetting: GizoStopRecordingSetting? = null
) {
    internal var mode: GizoRecordingType = GizoRecordingType.CAMERA
}