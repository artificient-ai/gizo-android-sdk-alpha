package de.artificient.gizo.sdk.model

internal sealed class NotificationEvent {
    data object BackgroundDefault : NotificationEvent()
    data object BackgroundStill : NotificationEvent()
    data object BackgroundNoCamera : NotificationEvent()
    data class InVehicleQuestion(val needPermission: Boolean) : NotificationEvent()
    data class RecordingFullQuestion(val needPermission: Boolean) : NotificationEvent()
}