package de.artificient.gizo.sdk.model

/**
 * Represents a list of recognized activities along with additional metadata about the recognition process.
 *
 * @property time The timestamp at which the activities were recognized.
 * @property isSimulated Indicates whether the activity data is simulated (true) or real (false).
 * @property isFromSensor Indicates whether the activity data was derived from sensor data (true) or other sources (false).
 * @property activities A list of [UserActivity] objects representing the recognized activities.
 */
data class ActivityRecognitionList(
    val time: Long,
    val isSimulated: Boolean = false,
    val isFromSensor: Boolean = false,
    val activities: List<UserActivity>
)