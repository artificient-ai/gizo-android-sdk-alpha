package de.artificient.gizo.sdk.model

/**
 * Enumerates types of device events that can be detected and processed by the SDK.
 * These events represent changes in the state of device features such as the microphone, screen, and telephony.
 */
enum class DeviceEventType {
    /**
     * Event type for microphone state changes. This can include states like whether the microphone is in use during a call or available.
     *
     * [DeviceEventStatus.MICROPHONE_IN_CALL], [DeviceEventStatus.MICROPHONE_AVAILABLE]
     */
    MICROPHONE,

    /**
     * Event type for screen state changes. This can include states like whether the screen is locked or unlocked.
     * [DeviceEventStatus.SCREEN_LOCKED], [DeviceEventStatus.SCREEN_UNLOCK]
     */
    SCREEN,

    /**
     * Event type for telephony state changes. This can include states like whether the phone is ringing, idle, or off-hook (in call).
     * [DeviceEventStatus.TELEPHONY_RINGING], [DeviceEventStatus.TELEPHONY_IDLE], [DeviceEventStatus.TELEPHONY_OFF_HOOK]
     */
    TELEPHONY,
}

