package de.artificient.gizo.sdk.model

enum class DelegateType {
    GPU,
    NNAPI,
    CPU
}