package de.artificient.gizo.sdk

import de.artificient.gizo.sdk.setting.GizoOptions

/**
 * Internal class for delegating GizoAppOptions with an optional callback on option change.
 *
 * @param options The GizoAppOptions instance to delegate.
 * @param onChange A lambda that will be called when the options are changed. It is an optional parameter.
 */
internal class GizoAppOptionsDelegate(var options: GizoOptions, var onChange: () -> Unit = {})
