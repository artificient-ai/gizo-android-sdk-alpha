package de.artificient.gizo.sdk.model

internal enum class GizoRecordingType {
    CAMERA,
    NO_CAMERA,
    BACKGROUND
}