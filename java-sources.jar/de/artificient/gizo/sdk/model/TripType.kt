package de.artificient.gizo.sdk.model

enum class TripType(val type: Int?) {
    None(null),
    NoCamera(3),
    BackgroundService(2),
    FUll(1)
}