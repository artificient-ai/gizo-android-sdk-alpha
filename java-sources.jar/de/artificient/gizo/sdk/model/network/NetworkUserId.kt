package de.artificient.gizo.sdk.model.network

import kotlinx.serialization.Serializable

@Serializable
data class NetworkUserId(val id: Long)

//fun NetworkUploadStart.asUploadStartModel() = de.artificient.gizo.sdk.model.UploadStart(
//    fileManagerId = fileManagerId,
//
//)

