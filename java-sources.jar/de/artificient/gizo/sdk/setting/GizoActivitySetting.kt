package de.artificient.gizo.sdk.setting

import de.artificient.gizo.sdk.model.FileLocationPath

/**
 * Configuration settings for handling user activity within the Gizo SDK.
 * This class defines settings related to tracking, saving, and managing user activity data.
 *
 * @property allowUserActivity Flag to enable or disable user activity tracking.
 * @property saveCsvFile Flag to enable or disable saving user activity data to a CSV file.
 * @property fileLocation The location where the CSV file will be saved.
 * @property interval The time interval (in milliseconds) for capturing user activity.
 */
class GizoActivitySetting private constructor(
    val allowActivity: Boolean,
    val saveCsvFile: Boolean,
) {

    /**
     * Generates a [Builder] instance with properties initialized from the current [GizoActivitySetting] instance.
     *
     * @return A [Builder] instance to further customize the user activity settings.
     */
    fun toBuilder(): Builder = Builder().apply {
        allowActivity(allowActivity)
        saveCsvFile(saveCsvFile)
    }

    /**
     * Builder class for [GizoActivitySetting]. Use this class to configure and create an instance of [GizoActivitySetting].
     */
    class Builder() {
        private var allowActivity: Boolean = false
        private var saveCsvFile: Boolean = false

        /**
         * Enables or disables user activity tracking.
         *
         * @param allowUserActivity Boolean value to enable or disable tracking.
         * @return The [Builder] instance for chaining method calls.
         */
        fun allowActivity(allowActivity: Boolean = false) =
            apply { this.allowActivity = allowActivity }

        /**
         * Enables or disables saving user activity data to a CSV file.
         *
         * @param saveCsvFile Boolean value to enable or disable saving to CSV.
         * @return The [Builder] instance for chaining method calls.
         */
        fun saveCsvFile(saveCsvFile: Boolean = false) =
            apply { this.saveCsvFile = saveCsvFile }

        /**
         * Builds a [GizoActivitySetting] instance with the configured settings.
         *
         * @return A configured [GizoActivitySetting] instance.
         */
        fun build(): GizoActivitySetting {
            return GizoActivitySetting(
                allowActivity = allowActivity,
                saveCsvFile = saveCsvFile
            )
        }
    }
}