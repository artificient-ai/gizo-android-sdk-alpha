package de.artificient.gizo.sdk.model

import de.artificient.gizo.sdk.setting.GizoBatterySetting

/**
 * Battery status
 *
 * @see [GizoBatterySetting]
 *
 * @see [BatteryStatus.LOW_BATTERY_WARNING]
 * @see [BatteryStatus.LOW_BATTERY_STOP]
 * @see [BatteryStatus.NORMAL]
 */
enum class BatteryStatus {
    /**
     * Low Battery Warning
     *
     */
    LOW_BATTERY_WARNING,

    /**
     * Low Battery Stop
     *
     */
    LOW_BATTERY_STOP,

    /**
     * Normal
     *
     */
    NORMAL
}