package de.artificient.gizo.sdk.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import de.artificient.gizo.sdk.Gizo
import de.artificient.gizo.sdk.GizoAppOptionsDelegate
import de.artificient.gizo.sdk.core.common.util.getAppIcon
import de.artificient.gizo.sdk.core.data.datasource.MapNavigationDataSource
import kotlinx.coroutines.launch

class ForegroundLocationService : LifecycleService() {

    private lateinit var mapNavigationDataSource: MapNavigationDataSource
    private val notificationId = 1
    private val channelId = "location_service_channel"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Location Service")
            .setContentText("Tracking location in the background")
            .setSmallIcon(getAppIcon(this))
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        startForeground(notificationId, notification)
        val options = Gizo.options
        mapNavigationDataSource = SharedData.mapNavigationDataSource
            ?: throw IllegalStateException("MapNavigationDataSource not initialized")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        mapNavigationDataSource.attachMapNavigationObserver()
        observeLocationUpdates()
        return START_STICKY
    }

    private fun observeLocationUpdates() {
        lifecycleScope.launch {
            mapNavigationDataSource.liveLocation.collect { location ->
//                Log.d("ForegroundService", "Location: $location")
                // Optionally save the location data to CSV or database
            }
        }
    }

    override fun onDestroy() {
        mapNavigationDataSource.detachMapNavigationObserver()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                channelId,
                "Foreground Location Service",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(serviceChannel)
        }
    }
}

internal object SharedData {
    var mapNavigationDataSource: MapNavigationDataSource? = null
}