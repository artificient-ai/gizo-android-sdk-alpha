package de.artificient.gizo.sdk

import android.content.Context
import android.location.Location
import androidx.camera.view.PreviewView
import androidx.lifecycle.LifecycleOwner
import de.artificient.gizo.sdk.config.GizoNoCameraSetting
import de.artificient.gizo.sdk.setting.GizoOptions
import kotlinx.coroutines.Job


interface IGizo {

    fun initialize(context: Context, options: GizoOptions): GizoInitializationResult

    //    fun start(config: GizoCameraSetting)
    fun start(config: GizoNoCameraSetting)

    fun stopRecording()

    var onStopRecording: ((
    ) -> Unit)?

    /**
     * On location change
     *
     * As mentioned earlier, this documentation provides instructions on enabling GPS, accessing location, speed, direction of movement (heading), and speed limit.
     * When GPS gets activated
     *
     * @param location A data class representing a geographic location. A location consists of a latitude, longitude, timestamp, accuracy, and other information such as bearing, altitude, and speed @see [Location].
     * @param isGpsOn To check whether the GPS is on or not.
     */
    var onLocationChange: ((
        location: Location?
    ) -> Unit)?

    /**
     * Camera initialized
     */
    val cameraInitialized: Boolean

    /**
     * Starts the camera with the given [LifecycleOwner]. This method initializes the camera and prepares it for use within the application.
     *
     * @param lifecycleOwner The lifecycle owner which controls the lifecycle of the camera.
     * @param onDone Callback invoked when the camera initialization is complete.
     * @return A [Job] representing the process of starting the camera.
     */
//    fun startCamera(lifecycleOwner: LifecycleOwner, onDone: () -> Unit): Job
    fun attachCamera(lifecycleOwner: LifecycleOwner, previewLayerCallback: (PreviewView) -> Unit): Job

}