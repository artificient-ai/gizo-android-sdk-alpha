package de.artificient.gizo.sdk.model

data class ChunkStatus(
    val fileChunkIds: List<Int>? = null,
    val chunkSize: Int? = null,
    val fileId: Long? = null,
    val isUploaded: Boolean? = null,
    val uploadPercent: Int? = 0,
    val fileType: Int? = null
)