package de.artificient.gizo.sdk.model

import de.artificient.gizo.sdk.core.data.model.GpsDataForLastTrip

internal data class TripDetailData(
    val originLat: String? = "",
    val originLng: String? = "",
    val originDuration: String? = "",
    val destinationLat: String? = "",
    val destinationLng: String? = "",
    val destinationDuration: String? = "",
    val gpsData: List<GpsDataForLastTrip>? = emptyList()
)