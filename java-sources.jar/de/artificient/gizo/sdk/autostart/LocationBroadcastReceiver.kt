package de.artificient.gizo.sdk.autostart

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.util.Log
import androidx.core.app.ActivityCompat
import java.io.File
import java.io.FileWriter
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

internal class LocationBroadcastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        try{
//            logToFile(context, "onReceive", "Start")
            // Check Wi-Fi status and hotspot status before proceeding
            if (!checkWifiStatusAndProceed(context)) {
//                logToFile(context, "onReceive", "Wifi is on, set Alarm Scheduler")
                AlarmScheduler().scheduleExactAlarm(context)
                return
            }
//            logToFile(context, "onReceive", "No wifi")

            // Check permissions before getting the location
            if (ActivityCompat.checkSelfPermission(
                    context, android.Manifest.permission.ACCESS_FINE_LOCATION
                ) != android.content.pm.PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(
                    context, android.Manifest.permission.ACCESS_COARSE_LOCATION
                ) != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
//                Log.e("LocationReceiver", "Location permissions not granted")
//                logToFile(context, "onReceive", "Don't have location permission")
                return
            }else {
//                logToFile(context, "onReceive", "Start location service, set Alarm Scheduler")
                AlarmScheduler().scheduleExactAlarm(context)
                val serviceIntent = Intent(context, LocationService::class.java)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    // Start the service as a foreground service for Android O and above
                    context.startForegroundService(serviceIntent)
                } else {
                    // Start it as a normal background service for pre-Oreo devices
                    context.startService(serviceIntent)
                }

            }
        }catch (e: Exception){
//            logToFile(context, "onReceive ERROR", "error message: $e")
        }
    }

//    // Function to check if Wi-Fi is available
//    @SuppressLint("MissingPermission")
//    private fun isWifiAvailable(context: Context): Boolean {
//        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
//        val activeNetwork = connectivityManager.activeNetwork ?: return false
//        val networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
//        return networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
//    }

    @SuppressLint("MissingPermission")
    fun checkWifiStatusAndProceed(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

//        logToFile(context, "Wifi", "activeNetwork: ${connectivityManager.activeNetwork}")
        val network = connectivityManager.activeNetwork ?: run {
//            logToFile(context, "Wifi", "No active network, Wi-Fi is not available")
            return true // No active network, Wi-Fi is not available, proceed with the service
        }

//        logToFile(context, "Wifi", "networkCapabilities: ${connectivityManager.getNetworkCapabilities(network)}")
        val networkCapabilities = connectivityManager.getNetworkCapabilities(network) ?: run {
//            logToFile(context, "Wifi", "No network capabilities, Wi-Fi is not available")
            return true // No network capabilities, Wi-Fi is not available, proceed with the service
        }

        // Check if the current network is Wi-Fi
        if (networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
//            logToFile(context, "Wifi", "current network is Wi-Fi: true")

            // Check if the Wi-Fi has internet capability
            if (networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
//                logToFile(context, "Wifi", "Wi-Fi has internet capability")

                // Check if the connection is metered (common for mobile hotspots)
                if (!networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)) {
//                    logToFile(context, "Wifi", "Network is metered, likely a hotspot")
                    return true // It's a hotspot, proceed with the service
                } else {
//                    logToFile(context, "Wifi", "Network is not metered, regular Wi-Fi with internet")
                    return false // Stop service, Wi-Fi is available with internet
                }
            } else {
//                logToFile(context, "Wifi", "Wi-Fi does not have internet capability")
                return true // Wi-Fi without internet, proceed with the service
            }
        } else {
//            logToFile(context, "Wifi", "Current network is not Wi-Fi")
            return true // Not a Wi-Fi network, proceed with the service
        }
    }

//    fun logToFile(context: Context, tag: String, description: String) {
//        // Define the file path and name
//        val fileName = "wifi.txt" // Log file name
//        val timeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
//
//        var directory = context.externalCacheDirs.firstOrNull()
//        val logDir = File(directory!!.absolutePath.toString(), "/Gizo")
//        if (!logDir.exists()) {
//            logDir.mkdirs() // Create directory if it doesn't exist
//        }
//
//        val logFile = File(logDir, fileName)
//        try {
//            if (!logFile.exists()) {
//                logFile.createNewFile() // Create file if it doesn't exist
//            }
//
//            // Prepare the log message
//            val currentTime = timeFormat.format(Date())
//            val logMessage = "$currentTime [$tag]: $description\n"
//
//            // Write the log message to the file
//            val fileWriter = FileWriter(logFile, true) // 'true' means append mode
//            fileWriter.append(logMessage)
//            fileWriter.flush()
//            fileWriter.close()
//
//            // Optionally show a Toast message on success
////            Toast.makeText(context, "Log saved successfully", Toast.LENGTH_SHORT).show()
//
//        } catch (e: IOException) {
//            // Handle errors
//            e.printStackTrace()
////            Toast.makeText(context, "Error writing log: ${e.message}", Toast.LENGTH_SHORT).show()
//        }
//    }
}