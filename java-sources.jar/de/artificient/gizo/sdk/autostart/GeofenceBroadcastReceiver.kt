package de.artificient.gizo.sdk.autostart

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent

internal class GeofenceBroadcastReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val geofencingEvent = GeofencingEvent.fromIntent(intent)
        if (geofencingEvent!!.hasError()) {
            Log.e(TAG, "Error receiving geofence event.")
            return
        }

        val transitionType = geofencingEvent.geofenceTransition
        val geofenceList = geofencingEvent.triggeringGeofences

        // Log the geofence event for debugging
//        Log.d(TAG, "Geofence transition: $transitionType")
        if (geofenceList != null) {
            for (geofence in geofenceList) {
//                Log.d(TAG, "Geofence ID: ${geofence.requestId}")
            }
        }

        val localIntent = Intent("GEOFENCE_TRANSITION_ACTION").apply {
            putExtra("transitionType", transitionType)
        }
        LocalBroadcastManager.getInstance(context).sendBroadcast(localIntent)

        when (transitionType) {
            Geofence.GEOFENCE_TRANSITION_ENTER -> {
//                sendNotification(context, "Entered Geofence")
            }
            Geofence.GEOFENCE_TRANSITION_DWELL -> {
//                sendNotification(context, "Dwelling in Geofence")
            }
            Geofence.GEOFENCE_TRANSITION_EXIT -> {
//                sendNotification(context, "Exited Geofence")
            }
        }
    }

    companion object {
        val TAG = GeofenceBroadcastReceiver::class.simpleName
    }
}
