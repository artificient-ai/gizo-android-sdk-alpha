package de.artificient.gizo.sdk.model.network

import kotlinx.serialization.Serializable

@Serializable
data class NetworkUploadStart(val fileManagerId: Long)

fun NetworkUploadStart.asUploadStartModel() = de.artificient.gizo.sdk.model.UploadStart(
    fileManagerId = fileManagerId,

)

