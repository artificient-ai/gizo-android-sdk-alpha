package de.artificient.gizo.sdk.upload

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Constraints
import androidx.work.ForegroundInfo
import androidx.work.NetworkType
import de.artificient.gizo.sdk.core.common.util.getAppIcon
import de.artificient.gizo.sdk.core.common.util.getAppName


private const val SyncNotificationId = 0
private const val SyncNotificationChannelID = "SyncNotificationChannel"
val SyncConstraints
    get() = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()

/**
 * Foreground information for sync on lower API levels when sync workers are being
 * run with a foreground service
 */
internal fun Context.syncForegroundInfo() = ForegroundInfo(
    SyncNotificationId,
    syncWorkNotification(),
)
/**
 * Notification displayed on lower API levels when sync workers are being
 * run with a foreground service
 */
private fun Context.syncWorkNotification(): Notification {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val channel = NotificationChannel(
            SyncNotificationChannelID,
            "Sync",
            NotificationManager.IMPORTANCE_DEFAULT,
        ).apply {
            description = "Sync trips info"
        }
        // Register the channel with the system
        val notificationManager: NotificationManager? =
            getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager

        notificationManager?.createNotificationChannel(channel)
    }

    return NotificationCompat.Builder(
        this,
        SyncNotificationChannelID,
    )
        .setSmallIcon(
            getAppIcon(this),
        )
        .setContentTitle(getAppName(this))
        .setContentText("Sync trips info")
        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
        .build()
}
