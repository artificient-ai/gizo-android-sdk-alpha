package de.artificient.gizo.sdk.setting

import de.artificient.gizo.sdk.model.FileLocationPath

/**
 * IMU setting in GIZO SDK allows developers to utilize the motion sensors of the device IMU. The IMU typically consists of the accelerometer, gyroscope, and magnetometer. Linear and gravity are estimated through the fusion of IMU data.
 *
 * GizoImuSetting can be used to customize the behaviour of an app by adjusting its reading and saving parameters.
 *
 * @property allowAccelerationSensor to activate the raw acceleration, linear acceleration, and gravity acceleration sensors or not.
 * @property allowGyroscopeSensor to activate the gyroscope sensor or not.
 * @property allowMagneticSensor to activate the magnetic field or not.
 * @property saveCsvFile to save CSV file or not.
 * @property fileLocation to save the IMU file, in the [FileLocationPath.CACHE] or [FileLocationPath.DOWNLOAD].
 * @property saveDataTimerPeriod the period of time that an IMU data row is saved in a CSV file.
 */
class GizoImuSetting private constructor(
    val allowAccelerationSensor: Boolean,
    val allowGyroscopeSensor: Boolean,
    val allowMagneticSensor: Boolean,
    val saveCsvFile: Boolean,
    val saveDataTimerPeriod: Long,
) {

    /**
     * Use it to regenerate Builder from current options
     *
     * @return
     */
    fun toBuilder(): Builder = Builder().apply {
        allowAccelerationSensor(allowAccelerationSensor)
        allowGyroscopeSensor(allowGyroscopeSensor)
        allowMagneticSensor(allowMagneticSensor)
        saveCsvFile(saveCsvFile)
        saveDataTimerPeriod(saveDataTimerPeriod)
    }

    /**
     * Builder
     *
     * @constructor Create [GizoImuSetting] instance.
     */
    class Builder() {
        private var allowAccelerationSensor: Boolean = false
        private var allowGyroscopeSensor: Boolean = false
        private var allowMagneticSensor: Boolean = false
        private var saveCsvFile: Boolean = false
        private var fileLocation: FileLocationPath = FileLocationPath.CACHE
        private var saveDataTimerPeriod: Long = 50L

        /**
         * Allow acceleration sensor to activate the raw acceleration, linear acceleration, and gravity acceleration sensors or not.
         *
         * @param allowAccelerationSensor
         */
        fun allowAccelerationSensor(allowAccelerationSensor: Boolean = false) =
            apply { this.allowAccelerationSensor = allowAccelerationSensor }

        /**
         * Allow gyroscope sensor to activate the gyroscope sensor or not.
         *
         * @param allowGyroscopeSensor
         */
        fun allowGyroscopeSensor(allowGyroscopeSensor: Boolean = false) =
            apply { this.allowGyroscopeSensor = allowGyroscopeSensor }

        /**
         * Allow magnetic sensor to activate the magnetic field or not.
         *
         * @param allowMagneticSensor
         */
        fun allowMagneticSensor(allowMagneticSensor: Boolean = false) =
            apply { this.allowMagneticSensor = allowMagneticSensor }


        /**
         * Save csv file to save CSV file or not.
         *
         * @param saveCsvFile
         */
        fun saveCsvFile(saveCsvFile: Boolean = false) = apply { this.saveCsvFile = saveCsvFile }

        /**
         * File location to save the IMU file, in the [FileLocationPath.CACHE] or [FileLocationPath.DOWNLOAD].
         *
         * @param fileLocation
         */
        fun fileLocation(fileLocation: FileLocationPath = FileLocationPath.CACHE) =
            apply { this.fileLocation = fileLocation }

        /**
         * Save data timer period the period of time that an IMU data row is saved in a CSV file.
         *
         * @param saveDataTimerPeriod
         */
        fun saveDataTimerPeriod(saveDataTimerPeriod: Long = 10L) =
            apply { this.saveDataTimerPeriod = saveDataTimerPeriod }

        fun build(): GizoImuSetting {
            return GizoImuSetting(
                allowAccelerationSensor = allowAccelerationSensor,
                allowGyroscopeSensor = allowGyroscopeSensor,
                allowMagneticSensor = allowMagneticSensor,
                saveCsvFile = saveCsvFile,
                saveDataTimerPeriod = saveDataTimerPeriod,
            )
        }
    }
}