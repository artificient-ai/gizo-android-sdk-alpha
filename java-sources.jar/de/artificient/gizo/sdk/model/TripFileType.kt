package de.artificient.gizo.sdk.model

enum class TripFileType(val type: Int) {
    VIDEO(0), IMU(1), GPS(2), TTC(4), MATRIX(5), ACTIVITY(6), APPS(7), PHONE_EVENTS(8), ACCIDENT(9)
}