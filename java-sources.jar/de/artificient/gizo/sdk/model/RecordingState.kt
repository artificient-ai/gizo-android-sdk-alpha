package de.artificient.gizo.sdk.model

enum class RecordingState {
    STILL,
    Background,
    Full,
    NoCamera,
}