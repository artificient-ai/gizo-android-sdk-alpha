package de.artificient.gizo.sdk

import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import de.artificient.gizo.sdk.core.GizoAnalysisImpl

/**
 * Internal class for observing the lifecycle of GizoAnalysisImpl and performing cleanup on onDestroy.
 *
 * @param analysis The GizoAnalysisImpl instance to observe.
 */
internal class GizoObserver(private val analysis: GizoAnalysisImpl) : DefaultLifecycleObserver {
    /** * This function is called when the owner's lifecycle is destroyed.
     *
     * It stops the analysis and detaches map navigation.
     *
     * @param owner The LifecycleOwner that is being destroyed.
     */
    override fun onDestroy(owner: LifecycleOwner) {
        super.onDestroy(owner)
//        analysis.stop()
//        analysis.detachMapNavigation()
    }
}