package de.artificient.gizo.sdk.model

data class User(
    val userToken: String = "",
    val userId: Long = -1,
    val companyToken: String = "",
    )
