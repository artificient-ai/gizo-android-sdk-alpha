package de.artificient.gizo.sdk.model

/**
 * Ttc alert
 *
 * TTC:time to collision value
 * @see [de.artificient.gizo.sdk.GizoAnalysis.ttcStatusCalculator]
 * @see [de.artificient.gizo.sdk.GizoAnalysis.onAnalysisResult]
 *
 * @see [TTCAlert.Collision]
 * @see [TTCAlert.Tailgating]
 * @see [TTCAlert.None]
 */
enum class TTCAlert {
    /**
     * Collision will be happening
     */
    Collision,

    /**
     * Tailgating will be happening
     */
    Tailgating,

    /**
     * None
     */
    None
}