package de.artificient.gizo.sdk.model.network

import de.artificient.gizo.sdk.model.UploadChunks
import kotlinx.serialization.Serializable

@Serializable
data class NetworkUploadChunks(val id: Long, val mergeStatus: Boolean?, val uploadPercent: Int){
    fun asUploadChunks(): UploadChunks = UploadChunks(
        id = id,
        mergeStatus = mergeStatus,
        uploadPercent = uploadPercent
    )
}
