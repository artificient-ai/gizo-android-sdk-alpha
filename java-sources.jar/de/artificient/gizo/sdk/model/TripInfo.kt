package de.artificient.gizo.sdk.model

import kotlinx.serialization.Serializable

@Serializable
data class TripInfo(
    val tripId: Long = 0,
    val isCompleted: Boolean = false,
    val originDuration: String = "",
    val originLat: String = "",
    val originLng: String = "",
    val destinationDuration: String = "",
    val destinationLat: String = "",
    val destinationLng: String = "",
    val duration: String = ""
)