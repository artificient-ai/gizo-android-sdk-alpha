package de.artificient.gizo.sdk

class GizoInitializationResult(
    val isSuccessful: Boolean,
    val failure: Throwable? = null
)