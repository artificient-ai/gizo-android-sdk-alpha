package de.artificient.gizo.sdk.setting

class GizoOptions private constructor(
    val logToConsole: Boolean,
    var logToFile:Boolean,
    val license: String,
    val useGizoScoring: Boolean,
    val useLocalScoring: Boolean,
    val autoStart: Boolean,
    val autoStop: Boolean,
    val uploadSetting: GizoUploadSetting = GizoUploadSetting.Builder().build(),
    var clientId: String,
    var clientSecret: String,
    ) {

    fun toBuilder(): Builder = Builder(license).apply {
        logToConsole(logToConsole)
        logToFile(logToFile)
        useGizoScoring(useGizoScoring)
        useLocalScoring(useLocalScoring)
        autoStart(autoStart)
        autoStop(autoStop)
        uploadSetting(uploadSetting)
        clientId(clientId)
        clientSecret(clientSecret)
    }

    class Builder(private val license: String ) {
        private var logToConsole: Boolean = true
        private var logToFile: Boolean = true
        private var useGizoScoring: Boolean = true
        private var useLocalScoring: Boolean = false
        private var autoStart: Boolean = true
        private var autoStop: Boolean = true
        private var uploadSetting: GizoUploadSetting = GizoUploadSetting.Builder().build()
        private var clientId: String = ""
        private var clientSecret: String = ""


        fun logToConsole(logToConsole: Boolean) = apply { this.logToConsole = logToConsole }
        fun logToFile(logToFile: Boolean) = apply { this.logToFile = logToFile }

        fun useGizoScoring(useGizoScoring: Boolean) =
            apply { this.useGizoScoring = useGizoScoring }

        fun useLocalScoring(useLocalScoring: Boolean) =
            apply { this.useLocalScoring = useLocalScoring }

        fun autoStart(autoStart: Boolean) =
            apply { this.autoStart = autoStart }

        fun autoStop(autoStop: Boolean) =
            apply { this.autoStop = autoStop }

        fun uploadSetting(uploadSetting: GizoUploadSetting) =
            apply { this.uploadSetting = uploadSetting }

        fun clientId(clientId: String) =
            apply { this.clientId = clientId }

        fun clientSecret(clientSecret: String) =
            apply { this.clientSecret = clientSecret }

        fun build(): GizoOptions {
            require(license.isBlank().not()){
                "License key is required"
            }

            return GizoOptions(
                license = license,
                logToConsole = logToConsole,
                logToFile = logToFile,
                useGizoScoring = useGizoScoring,
                useLocalScoring = useLocalScoring,
                autoStart = autoStart,
                autoStop = autoStop,
                uploadSetting = uploadSetting,
                clientId = clientId,
                clientSecret = clientSecret
            )
        }
    }
}