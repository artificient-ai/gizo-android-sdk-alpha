package de.artificient.gizo.sdk.autostart

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import de.artificient.gizo.sdk.Gizo
import de.artificient.gizo.sdk.GizoAppOptionsDelegate
import de.artificient.gizo.sdk.core.common.Constants
import de.artificient.gizo.sdk.core.common.util.getAppIcon
import de.artificient.gizo.sdk.core.domain.DomainProvider
import de.artificient.gizo.sdk.core.domain.usecase.GetLocationGeofencingUseCase
import de.artificient.gizo.sdk.core.domain.usecase.SetLocationGeofencingUseCase
import de.artificient.gizo.sdk.service.RecordingBackgroundService
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileWriter
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

internal class LocationService : Service() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationRequest: LocationRequest
    private lateinit var locationCallback: LocationCallback

    private var locationChangeCount = 0 // Counter for location changes
    private val maxLocationChanges = 1 // Maximum number of location changes
    private var locationCount = 0 // Counter for location changes
    private val maxLocation = 12 // Maximum number of location changes
    private var previousLocationLocal: Location? = null // Store the previous location

    private lateinit var setLocationGeofencingUseCase: SetLocationGeofencingUseCase
    private lateinit var getLocationGeofencingUseCase: GetLocationGeofencingUseCase

    val options = Gizo.options
    val optionsDelegate = GizoAppOptionsDelegate(options)

    override fun onCreate() {
        super.onCreate()
        try {
            // Manually provide dependencies
            setLocationGeofencingUseCase = DomainProvider.provideSetLocationGeofencingUseCase(this, optionsDelegate)
            getLocationGeofencingUseCase = DomainProvider.provideGetLocationGeofencingUseCase(this, optionsDelegate)
//            logToFile(this, "onCreate", "Start")
            fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

            // Updated request to get location as soon as possible
            locationRequest = LocationRequest.Builder(
                Priority.PRIORITY_HIGH_ACCURACY, // High accuracy for quick and precise location
                2 * 1000 // Interval in milliseconds (2 seconds)
            ).apply {
                setMinUpdateIntervalMillis(1 * 1000) // Fastest interval (1 seconds)
            }.build()

            var context = this

            locationCallback = object : LocationCallback() {
                override fun onLocationResult(locationResult: LocationResult) {
                    super.onLocationResult(locationResult)
//                    logToFile(context, "locationCallback", "locationCallback Start")
                    for (location in locationResult.locations) {
                        locationCount++
                        location?.let {

                            if (previousLocationLocal != null) {
//                                logToFile(context, "locationCallback", "previous location local: ${previousLocationLocal!!.latitude}, ${previousLocationLocal!!.longitude}")
//                                logToFile(context, "locationCallback", "location: ${location.latitude}, ${location.longitude}")
                                if ((previousLocationLocal!!.latitude != location.latitude &&
                                            previousLocationLocal!!.longitude != location.longitude) &&
                                    (location.time > (System.currentTimeMillis() - 20000))
                                ) {
                                    locationChangeCount++

//                                val locationTimeString = Date(location.time).toString(CSV_DATE_TIME_FORMAT)
//                                Log.d("LocationReceiver", "Location ${locationChangeCount + 1}: ${location.latitude}, ${location.longitude} - time: $locationTimeString")
                                }
                                // Stop after maxLocationChanges
                                if (locationChangeCount >= maxLocationChanges) {
                                    GlobalScope.launch {
                                        // Get the location from getLocationGeofencingUseCase
                                        val previousLocation =
                                            getLocationGeofencingUseCase().firstOrNull()

                                        if (previousLocation == null) {
//                                            logToFile(context, "locationCallback", "previous location database: null")
//                                            logToFile(context, "onCreate", "Stop")
                                            // If getLocationGeofencingUseCase returns null, stop the service
                                            stopLocationUpdates()
                                            stopSelf()
                                            return@launch // Exit the coroutine early
                                        }
//                                        logToFile(context, "locationCallback", "previous location database: ${previousLocation.latitude}, ${previousLocation.longitude}")

                                        val distance = previousLocation.distanceTo(location)

//                                        Log.d(
//                                            "LocationReceiver",
//                                            "Previous Location: ${previousLocation.latitude}, ${previousLocation.longitude} - Current Location: ${location.latitude}, ${location.longitude} - Distance: $distance"
//                                        )

//                                        logToFile(context, "locationCallback", "Previous Location: ${previousLocation.latitude}, ${previousLocation.longitude} - Current Location: ${location.latitude}, ${location.longitude} - Distance: $distance")

                                        // If the distance is more than 100, start RecordingBackgroundService
                                        if (distance > 100) {
                                            if(Constants.licenseType != -1) {

                                                if (options.autoStart) {
                                                    if (!RecordingBackgroundService.isRunning(
                                                            context
                                                        )
                                                    ) {
//                                                        Log.d(
//                                                            "LocationReceiver",
//                                                            "Start background service"
//                                                        )
//                                                        logToFile(context, "onCreate", "RecordingBackgroundService.startService")

                                                        RecordingBackgroundService.startService(
                                                            context
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        delay(2000) // Delay for 2 seconds
//                                        logToFile(context, "onCreate", "Stop after maxLocationChanges")
                                        stopLocationUpdates()
                                        stopSelf() // Stop the service
                                    }
                                }

                            }

                            // Update previousLocation with the current location
                            previousLocationLocal = location
                        }

                        if (locationCount >= maxLocation) {
                            GlobalScope.launch {
                                // Get the location from getLocationGeofencingUseCase
                                val previousLocation =
                                    getLocationGeofencingUseCase().firstOrNull()

                                if (previousLocation == null) {
//                                    logToFile(context, "locationCount10", "previous location database: null")
//                                    logToFile(context, "locationCount10", "Stop")
                                    // If getLocationGeofencingUseCase returns null, stop the service
                                    stopLocationUpdates()
                                    stopSelf()
                                    return@launch // Exit the coroutine early
                                }
//                                logToFile(context, "locationCount10", "previous location database: ${previousLocation.latitude}, ${previousLocation.longitude}")

                                val distance = previousLocation.distanceTo(location)

//                                logToFile(context, "locationCount10", "Previous Location: ${previousLocation.latitude}, ${previousLocation.longitude} - Current Location: ${location.latitude}, ${location.longitude} - Distance: $distance")

                                // If the distance is more than 100, start RecordingBackgroundService
                                if (distance > 100) {
                                    if(Constants.licenseType != -1) {

                                        if (options.autoStart) {
                                            if (!RecordingBackgroundService.isRunning(context)) {
//                                                Log.d(
//                                                    "LocationReceiver",
//                                                    "Start background service"
//                                                )
//                                                logToFile(context, "locationCount10", "Starting RecordingBackgroundService")

                                                RecordingBackgroundService.startService(context)
                                            }
                                        }
                                    }
                                }

                                delay(2000) // Delay for 2 seconds
//                                logToFile(context, "onCreate", "Stop")
                                stopLocationUpdates()
                                stopSelf() // Stop the service
                            }
                        }
                    }
                }
            }

            startForegroundService()
            startLocationUpdates(this)
        }catch (e: Exception){
//            logToFile(this, "onCreate ERROR", "error message: $e")
        }
    }

    @SuppressLint("ForegroundServiceType")
    private fun startForegroundService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelId = "location_channel"
            val channelName = "Location Service"
            val channel = NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_LOW)
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)

            val notification = NotificationCompat.Builder(this, channelId)
                .setContentTitle("Location Service")
                .setContentText("Tracking location in the background")
                .setSmallIcon(getAppIcon(this))
                .setSilent(true)
                .setVisibility(NotificationCompat.VISIBILITY_SECRET)
                .build()

            startForeground(1, notification)
        } else {
            val notification = NotificationCompat.Builder(this)
                .setContentTitle("Location Service")
                .setContentText("Tracking location in the background")
                .setSmallIcon(getAppIcon(this))
                .setSilent(true)
                .setVisibility(NotificationCompat.VISIBILITY_SECRET)
                .build()

            startForeground(1, notification)
        }
    }

    @SuppressLint("MissingPermission")
    private fun startLocationUpdates(context: Context) {
        // Start continuous location updates
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null)
    }

    override fun onDestroy() {
        super.onDestroy()
        stopLocationUpdates()
    }

    private fun stopLocationUpdates() {
        fusedLocationClient.removeLocationUpdates(locationCallback)
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

//    fun logToFile(context: Context, tag: String, description: String) {
//        // Define the file path and name
//        val fileName = "location_service.txt" // Log file name
//        val timeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
//
//        var directory = context.externalCacheDirs.firstOrNull()
//        val logDir = File(directory!!.absolutePath.toString(), "/Gizo")
//        if (!logDir.exists()) {
//            logDir.mkdirs() // Create directory if it doesn't exist
//        }
//
//        val logFile = File(logDir, fileName)
//        try {
//            if (!logFile.exists()) {
//                logFile.createNewFile() // Create file if it doesn't exist
//            }
//
//            // Prepare the log message
//            val currentTime = timeFormat.format(Date())
//            val logMessage = "$currentTime [$tag]: $description\n"
//
//            // Write the log message to the file
//            val fileWriter = FileWriter(logFile, true) // 'true' means append mode
//            fileWriter.append(logMessage)
//            fileWriter.flush()
//            fileWriter.close()
//
//        } catch (e: IOException) {
//            // Handle errors
//            e.printStackTrace()
//        }
//    }
}