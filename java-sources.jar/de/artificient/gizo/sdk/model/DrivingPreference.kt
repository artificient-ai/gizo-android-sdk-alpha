package de.artificient.gizo.sdk.model

data class DrivingPreference(
    val enableEmergencyContact: Int = 1,
    val collisionDetection: Int = 1,
    val liveCameraView: Int = 1,
    val trafficLights: Int = 1,
    val tailgating: Int = 1,
    val collisionThreshold: Float = .5f,
    val usingAi: Boolean = true,
    val backgroundRecordActive: Boolean = true,
    val backgroundRecordEnable: Boolean = true,
)
