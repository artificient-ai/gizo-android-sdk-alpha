package de.artificient.gizo.sdk

import android.location.Location
import androidx.camera.view.PreviewView
import androidx.lifecycle.LifecycleOwner
import de.artificient.gizo.sdk.config.GizoNoCameraSetting
import de.artificient.gizo.sdk.setting.GizoOptions
import kotlinx.coroutines.Job

/**
 *
 * In this library, using artificial intelligence, driving behavior is analyzed, and a series of data is computed to reduce the risk of accidents and other driving hazards. As a result, the possibility of smarter and safer driving is provided to users.
 *
 */
interface GizoAnalysis {

    /**
     * Gizo analysis options.
     *
     * Variable to access current [GizoAppOptions]
     */
    val options: GizoOptions

//    fun start(config: GizoCameraSetting)
    fun start(config: GizoNoCameraSetting)

    fun stopRecording()

    var didStopRecording: ((
    ) -> Unit)?

    var didStartRecording: ((
    ) -> Unit)?

    /**
     * On location change
     *
     * As mentioned earlier, this documentation provides instructions on enabling GPS, accessing location, speed, direction of movement (heading), and speed limit.
     * When GPS gets activated
     *
     * @param location A data class representing a geographic location. A location consists of a latitude, longitude, timestamp, accuracy, and other information such as bearing, altitude, and speed @see [Location].
     * @param isGpsOn To check whether the GPS is on or not.
     */
    var didUpdateLocation: ((
        location: Location?
    ) -> Unit)?

    var onStartUploadTrip: ((
        tripId: Long?
    ) -> Unit)?

    var onCompleteUploadTrip: ((
        tripId: Long?
    ) -> Unit)?
//    /**
//     * Lock preview attaches the preview screen, while the unlock preview detaches it. They are used to give developers the ability to preview or not.
//     */
//    val lockPreview: Boolean
//
//    /**
//     * Battery last status
//     */
//    val batteryLastStatus: BatteryStatus
//
    /**
     * Camera initialized
     */
    val cameraInitialized: Boolean
//
//
//
//
//    /**
//     * Stop analysis whenever we no longer need the SDK, we should call the stop function to halt all ongoing operations within the library.
//     * These processes include video recording, GPS, IMU, analysis, and so on…
//     *
//     *  @see [start]
//     *
//     */
//    fun stop()
//
//    /**
//     * Attach [PreviewView] that displays the camera feed for CameraX’s Preview use case.
//     * This class manages the preview of surface’s lifecycle.
//     * After 1: Either a TextureView or a SurfaceView is used internally to display the camera feed, and necessary transformations are applied to display the preview correctly.
//     * These transformations include correcting aspect ratio, scale, and rotation.
//     * So, to display the camera, a previewView should be attached as well.
//     *
//     * @param previewView [PreviewView] from camerax package
//     */
//    fun attachPreview(previewView: PreviewView)
//
//    /**
//     * Start saving session files
//     *
//     * Based on the settings we have applied, some files related to video, analysis, GPS, and IMU are saved.
//     *
//     * Saving files in Android Studio has benefits like data persistence, offline accessibility, advanced analysis, sharing, backup, and tracking. It enhances the functionality, usability, and reliability of your app by ensuring the availability and integrity of important data.
//     *
//     * @param videoRecording Indicates whether video recording should be started (true by default).
//     * @param gpsRecording Indicates whether GPS recording should be started (true by default).
//     *
//     * @receiver
//     */
//    suspend fun startSavingSession(
//        videoRecording: Boolean = true,
//        gpsRecording: Boolean = true
//    )
//
//    /**
//     * Stop saving session files
//     *
//     * While saving files is an essential aspect of many applications, it’s important to consider the performance, battery, storage, security, and network implications associated with file-saving operations. By optimizing and managing file-saving processes, you can ensure a smooth user experience while efficiently utilizing system resources.
//     *
//     * Use this function to stop saving files after [startSavingSession].
//     *
//     */
//    suspend fun stopSavingSession()
//
//    /**
//     * Pause or Resume analysis temporary
//     *
//     * @param isLock
//     */
//    fun lockAnalysis(isLock: Boolean)
//
//    /**
//     * Once the Lock Preview feature is enabled, the preview will remain fixed to the chosen device configuration until the feature is disabled or the configuration is changed.
//     *
//     * By using the Lock Preview feature, developers can maintain a focused and consistent preview display, allowing for more efficient UI design and testing in Android Studio.
//     */
//    fun lockPreview()
//
//    /**
//     * the Unlock Preview is the counterpart to the [lockPreview] feature in the XML layout editor’s Preview pane. When the Unlock Preview feature is enabled, it allows the preview display to dynamically update and adapt to changes made to the XML layout or other settings.
//     *
//     * @param previewView
//     */
//    fun unlockPreview(previewView: PreviewView)
//
////    /**
////     * Ttc calculator
////     *
////     *
////     * @param ttcCalculator
////     */
////    fun ttcCalculator(ttcCalculator: (frontObject: String, speed: Float?, ttc: Float?) -> Float?)
////
////    /**
////     * Ttc status calculator
////     *
////     * @param ttcStatusCalculator
////     */
////    fun ttcStatusCalculator(ttcStatusCalculator: (ttc: Float?, speed: Float?, ttcStatus: TTCAlert) -> TTCAlert)
//
////    /**
////     * On analysis result we require accurate and efficient detection and localization of objects in images and video streams and also accurate and efficient estimation of the depth or distance of objects in a scene and we gain these data with [de.artificient.gizo.sdk.setting.GizoAnalysisSettings].
////     *
////     * @param preview It outputs an image that includes object detection and road lines.
////     * @param ttc Time to collision.
////     * @param ttcStatus It returns state collision, tailgating, and None based on the calculated formula in the TTC.
////     * @param frontObjectDistance The distance to the front object.
////     * @param egoSpeed The speed of the ego vehicle.
////     * @param gpsTime The current time.
////     */
////    var onAnalysisResult: ((preview: Bitmap?, ttc: Float?, ttcStatus: TTCAlert, frontObject: String, speed: Float?, gpsTime: String) -> Unit)?
//
//    /**
//     * On battery status refer to the configuration and management options related to the battery state of the device. These settings allow monitoring and controlling the battery usage of their mobile devices.
//     *
//     * @param status To check what is the battery status: [BatteryStatus.LOW_BATTERY_STOP], [BatteryStatus.LOW_BATTERY_WARNING], or [BatteryStatus.NORMAL]
//     */
//    var onBatteryStatusChange: ((BatteryStatus) -> Unit)?
//
//    /**
//     * On video recording status
//     *
//     * @param inProgress To check whether the session is recording or not.
//     * @param previewAttached To check whether the preview is attached or not.
//     */
//    var onSessionStatus: ((
//        inProgress: Boolean,
//    ) -> Unit)?
//
//    var onVideoSessionStatus: ((
//        isVideoRecording: Boolean,
//        previewAttached: Boolean
//    ) -> Unit)?
//

//
//    /**
//     * On speed change
//     *
//     * @param speedLimitKph speed limit in kilometer per hour.
//     * @param speedKph speed in kilometer per hour.
//     */
//    var onSpeedChange: ((
//        speedLimitKph: Int?,
//        speedKph: Int,
//    ) -> Unit)?
//
//    /**
//     * On linear acceleration sensor Event
//     *
//     * @param sensorEvent includes information such as Linear Acceleration values, Timestamps and Accuracy, or precision.
//     */
//    var onLinearAccelerationSensor: ((
//        sensorEvent: SensorEvent?,
//    ) -> Unit)?
//
//    /**
//     * On gyroscope sensor Event
//     *
//     * @param sensorEvent includes information such as Angular velocity values, timestamps and Accuracy, or precision.
//     */
//    var onGyroscopeSensor: ((
//        sensorEvent: SensorEvent?,
//    ) -> Unit)?
//
//    /**
//     * On Magnetic sensor Event
//     *
//     * @param sensorEvent includes information such as Magnetic field values, timestamps and Accuracy, or precision.
//     */
//    var onMagneticSensor: ((sensorEvent: SensorEvent?) -> Unit)?
//
//    /**
//     * On imu sensor Event
//     *
//     * @param accelerationEvent includes information such as Acceleration values, Timestamps and Accuracy, or precision.
//     * @param linearAccelerationEvent includes information such as Linear Acceleration values, Timestamps and Accuracy, or precision.
//     * @param accelerationUncalibratedEvent includes information such as Uncalibrated Acceleration values, Timestamps and Accuracy, or precision.
//     * @param gyroscopeEvent includes information such as Angular velocity values, timestamps and Accuracy, or precision.
//     * @param magneticEvent includes information such as Magnetic field values, timestamps and Accuracy, or precision.
//     * @param gravityEvent includes information such as Gravity values, timestamps and Accuracy, or precision.
//     */
//    var onImuSensor: ((
//        accelerationEvent: SensorEvent?,
//        linearAccelerationEvent: SensorEvent?,
//        accelerationUncalibratedEvent: SensorEvent?,
//        gyroscopeEvent: SensorEvent?,
//        magneticEvent: SensorEvent?,
//        gravityEvent: SensorEvent?,
//    ) -> Unit)?
//
//    /**
//     * On recording event Event
//     *
//     * When the video gets activated, this value parameter can be checked out
//     *
//     * ```
//     * when (event) {
//     *     is VideoRecordEvent.Finalize -> {
//     *         if (event.hasError()) {
//     *             //Do something
//     *         }
//     *     }
//     * }
//     *
//     * ```
//     * @see [VideoRecordEvent]
//     * @param event Used to report video recording events and status.
//     */
//    var onRecordingEvent: ((event: VideoRecordEvent) -> Unit)?
//
//    /**
//     * On gravity sensor Event
//     *
//     * @param sensorEvent includes information such as Gravity values, timestamps and Accuracy, or precision.
//     *
//     */
//    var onGravitySensor: ((sensorEvent: SensorEvent?) -> Unit)?
//
//    /**
//     * On acceleration sensor Event
//     *
//     * @param sensorEvent includes information such as Acceleration values, Timestamps and Accuracy, or precision.
//     *
//     */
//    var onAccelerationSensor: ((sensorEvent: SensorEvent?) -> Unit)?
//
//    /**
//     * On acceleration uncalibrated sensor Event
//     *
//     * @param sensorEvent includes information such as Uncalibrated Acceleration values, Timestamps and Accuracy, or precision.
//     */
//    var onAccelerationUncalibratedSensor: ((sensorEvent: SensorEvent?) -> Unit)?
//
//    /**
//     * On gravity alignment change
//     *
//     * @param isAlign Whether the mobile device is in a landscape orientation or not.
//     *
//     */
//    var onGravityAlignmentChange: ((isAlign: Boolean?) -> Unit)?
//
//    /**
//     * Callback for receiving microphone sensor events.
//     *
//     */
//    var onMicrophoneSensor: ((event: DeviceEventStatus) -> Unit)?
//
//    /**
//     * Callback for receiving active application information. It provides details about the application package name, category, label, and whether it's a system app.
//     */
//    var onActiveApp: ((appPackage: String?, category: String?, label: String?, system: Boolean?) -> Unit)?
//
//    /**
//     * Callback for receiving telephony sensor events.
//     */
//    var onTelephonySensor: ((event: DeviceEventStatus) -> Unit)?
//
//    /**
//     * Callback for receiving screen lock events.
//     */
//    var onScreenLock: ((event: DeviceEventStatus) -> Unit)?
//
//    /**
//     * Callback for receiving device event information. It provides details about the event and its value.
//     */
//    var onDeviceEvent: ((event: DeviceEventType, value: DeviceEventStatus) -> Unit)?
//
//    /**
//     * Callback for receiving thermal status changes. It informs about the thermal condition of the device.
//     */
//    var onThermalStatusChange: ((ThermalStatus) -> Unit)?
//
//    /**
//     * Holds the last thermal status of the device.
//     */
//    val thermalLastStatus: ThermalStatus
//
//    /**
//     * Callback for receiving temperature changes. It provides the current temperature.
//     */
//    var onTemperatureChange: ((Int) -> Unit)?
//
//    /**
//     * Holds the last recorded temperature.
//     */
//    val lastTemperature: Int?
//
//    /**
//     * Callback for receiving user activity information. It provides details about the time and a list of user activities.
//     */
//    var onUserActivity: ((time: Long, activities: List<UserActivity>) -> Unit)?
//
//    /**
//     * Holds the current user activity type.
//     */
//    val currentUserActivity: UserActivityType
//
//    /**
//     * Indicates whether the device is in driving mode.
//     */
//    val isInDrivingMode: Boolean
//
////    /**
////     * Binds map navigation functionalities with a [LifecycleOwner]. This is essential for integrating map-based navigation features within the application.
////     *
////     * @param lifecycleOwner The lifecycle owner which controls the lifecycle of the map navigation.
////     */
////    fun bindMapNavigation(lifecycleOwner: LifecycleOwner)
////
////    /**
////     * Attaches map navigation functionalities, enabling the application to start utilizing map-based features.
////     */
////    fun attachMapNavigation()
//
////    /**
////     * Detaches map navigation functionalities, stopping the application from utilizing map-based features.
////     */
////    fun detachMapNavigation()
//
//    /**
//     * Stops the camera. This method should be called when the application no longer needs to use the camera.
//     */
//    fun stopCamera()
//
    /**
     * Starts the camera with the given [LifecycleOwner]. This method initializes the camera and prepares it for use within the application.
     *
     * @param lifecycleOwner The lifecycle owner which controls the lifecycle of the camera.
     * @param onDone Callback invoked when the camera initialization is complete.
     * @return A [Job] representing the process of starting the camera.
     */
//    fun startCamera(lifecycleOwner: LifecycleOwner, onDone: () -> Unit): Job
    fun attachCamera(lifecycleOwner: LifecycleOwner, previewLayerCallback: (PreviewView) -> Unit): Job

//
//    /**
//     * Is saving session in progress
//     *
//     * Use this function to check if session is started or not
//     *
//     * @return A [Boolean] it will be true between [startSavingSession] and [stopSavingSession]
//     */
//    fun isSavingSessionInProgress(): Boolean
}