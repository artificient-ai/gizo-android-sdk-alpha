package de.artificient.gizo.sdk.model

import de.artificient.gizo.sdk.core.data.datasource.UploadFileManager
import java.io.File

internal data class TripFile(
    val path: String,
    val pathWithSecondName: String,
    val files: List<File>,
     val latestLocalTripInfo: UploadFileManager.CheckTripModel,
    val isCompleted: Boolean,
    val tripId: Long,
    val dirSize: Float,
) {
    fun mapTrip(): Trip {
        return Trip(
            id = tripId,
            isCompleted = isCompleted,
            score = 0.0,
            createDate = path.replaceBeforeLast("/", "").replace("/", ""),
            startDateTime = latestLocalTripInfo.tripInfo.originDuration,
            endDateTime = latestLocalTripInfo.tripInfo.destinationDuration,
            duration = latestLocalTripInfo.tripInfo.duration,
            originLat = latestLocalTripInfo.tripInfo.originLat,
            originLng = latestLocalTripInfo.tripInfo.originLng,
            destinationLat = latestLocalTripInfo.tripInfo.destinationLat,
            destinationLng = latestLocalTripInfo.tripInfo.destinationLng,
            isLocalTrip = true,
            isPrepareToShow = false,
            transportationType = TransportationType.Driver,
            iAmDriver = true,
            hasAccident = false
        )
    }
}