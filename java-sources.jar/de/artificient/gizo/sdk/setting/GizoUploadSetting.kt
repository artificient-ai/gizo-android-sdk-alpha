package de.artificient.gizo.sdk.setting

class GizoUploadSetting private constructor(
    val isMobileDataEnabled: Boolean,
    val isRoamingDataEnabled: Boolean,
    val mobileDataUsageLimit: Double,
    val roamingDataUsageLimit: Double,
) {

    fun toBuilder(): Builder = Builder().apply {
        isMobileDataEnabled(isMobileDataEnabled)
        isRoamingDataEnabled(isRoamingDataEnabled)
        mobileDataUsageLimit(mobileDataUsageLimit)
        roamingDataUsageLimit(roamingDataUsageLimit)
    }

    class Builder() {
        private var isMobileDataEnabled: Boolean = true
        private var isRoamingDataEnabled: Boolean = false
        private var mobileDataUsageLimit: Double = 100.0
        private var roamingDataUsageLimit: Double = 100.0

        fun isMobileDataEnabled(isMobileDataEnabled: Boolean = true) =
            apply { this.isMobileDataEnabled = isMobileDataEnabled }

        fun isRoamingDataEnabled(isRoamingDataEnabled: Boolean = false) =
            apply { this.isRoamingDataEnabled = isRoamingDataEnabled }

        fun mobileDataUsageLimit(mobileDataUsageLimit: Double = 100.0) =
            apply { this.mobileDataUsageLimit = mobileDataUsageLimit }

        fun roamingDataUsageLimit(roamingDataUsageLimit: Double = 100.0) =
            apply { this.roamingDataUsageLimit = roamingDataUsageLimit }

        fun build(): GizoUploadSetting {
            return GizoUploadSetting(
                isMobileDataEnabled = isMobileDataEnabled,
                isRoamingDataEnabled = isRoamingDataEnabled,
                mobileDataUsageLimit = mobileDataUsageLimit,
                roamingDataUsageLimit = roamingDataUsageLimit,
            )
        }
    }
}