package de.artificient.gizo.sdk.setting

import de.artificient.gizo.sdk.model.AnalysisDelegateType
import de.artificient.gizo.sdk.model.FileLocationPath
import de.artificient.gizo.sdk.model.ThresholdType

/**
 * Gizo analysis settings used to customize some behavior and functionality of our library including specifying the processing method on the model, the distance from the windshield to the hood of the car, the initial amount of timer, time to collision number (TTC), where to save the file, what period interval the data should be saved and sent & where to save matrix file.
 *
 * @property allowAnalysis Enabling the analysis feature.
 * @property modelName Providing the name of the model in assets folder to be used for analysis. required
 * @property loadDelegate Specifying the analysis delegate type as [AnalysisDelegateType], which determines the best delegate based on the device capabilities.
 * @property carHeight Setting the height of the car for analysis.
 * @property collisionThreshold The number that is used in the TTC calculations collision.
 * @property tailgatingThreshold The number that is used in the TTC calculations tailgating.
 * @property saveTtcCsvFile Indicating that the TTC data should be saved to a file.
 * @property ttcFileLocation Specifying the file location path for storing Time-to-Collision (TTC) data (in this case, set to the cache directory)
 * @property saveDataTimerPeriod Setting the period of the TTC data timer to 30 milliseconds.
 * @property saveMatrixFile Indicating that the analysis matrix file should be saved.
 * @property matrixFileLocation Indicating that the TTC data should be saved to a file.
 * @constructor Create empty Gizo analysis settings
 */
class GizoAnalysisSettings private constructor(
    val allowAnalysis: Boolean,
    val modelName: String,
    val carHeight: Double,
    val collisionThreshold: Float?,
    val tailgatingThreshold: Float?,
    val saveTtcCsvFile: Boolean,
    val ttcFileLocation: FileLocationPath,
    val saveDataTimerPeriod: Long,
    val saveMatrixFile: Boolean,
    val matrixFileLocation: FileLocationPath,
) {

    /**
     * To builder
     *
     * @return
     */
    fun toBuilder(): Builder = Builder().apply {
        allowAnalysis(allowAnalysis)
        modelName(modelName)
        saveTtcCsvFile(saveTtcCsvFile)
        ttcFileLocation(ttcFileLocation)
        saveDataTimerPeriod(saveDataTimerPeriod)
        saveMatrixFile(saveMatrixFile)
        matrixFileLocation(matrixFileLocation)
        if (collisionThreshold != null)
            collisionThreshold(collisionThreshold)
        else
            collisionThreshold(ThresholdType.None)
        if (tailgatingThreshold != null)
            tailgatingThreshold(tailgatingThreshold)
        else
            tailgatingThreshold(ThresholdType.None)
    }

    /**
     * Builder
     *
     * @constructor Create empty Builder
     */
    class Builder() {
        private var allowAnalysis: Boolean = false
        private var modelName: String = ""
        private var carHeight: Double = 1.6
        private var collisionThreshold: Float? = 0.5f
        private var tailgatingThreshold: Float? = 1f

        private var saveTtcCsvFile: Boolean = false
        private var ttcFileLocation: FileLocationPath = FileLocationPath.CACHE
        private var saveMatrixFile: Boolean = false
        private var matrixFileLocation: FileLocationPath = FileLocationPath.CACHE
        private var saveDataTimerPeriod: Long = 30L

        /**
         * Allow analysis enabling the analysis feature.
         *
         * @param allowAnalysis
         */
        fun allowAnalysis(allowAnalysis: Boolean = false) =
            apply { this.allowAnalysis = allowAnalysis }

        /**
         * Model name
         *
         * @param modelName
         */
        fun modelName(modelName: String) = apply { this.modelName = modelName }

        /**
         * Collision threshold
         *
         * @param collisionThreshold
         */
        fun collisionThreshold(collisionThreshold: Float = 0.5f) =
            apply { this.collisionThreshold = collisionThreshold }

        /**
         * Tailgating threshold the number that is used in the TTC calculations tailgating.
         *
         * @param tailgatingThreshold
         */
        fun tailgatingThreshold(tailgatingThreshold: Float = 1f) =
            apply { this.tailgatingThreshold = tailgatingThreshold }

        /**
         * Collision threshold the number that is used in the TTC calculations collision.
         *
         * @param type
         */
        fun collisionThreshold(type: ThresholdType) =
            apply { this.collisionThreshold = null }

        /**
         * Tailgating threshold
         *
         * @param type
         */
        fun tailgatingThreshold(type: ThresholdType) =
            apply { this.tailgatingThreshold = null }

        /**
         * Save ttc csv file indicating that the TTC data should be saved to a file.
         *
         * @param saveTtcCsvFile
         */
        fun saveTtcCsvFile(saveTtcCsvFile: Boolean = false) =
            apply { this.saveTtcCsvFile = saveTtcCsvFile }

        /**
         * Ttc file location specifying the file location path for storing Time-to-Collision (TTC) data (in this case, set to the cache directory)
         *
         * @param ttcFileLocation
         */
        fun ttcFileLocation(ttcFileLocation: FileLocationPath = FileLocationPath.CACHE) =
            apply { this.ttcFileLocation = ttcFileLocation }

        /**
         * Save data timer period setting the period of the TTC data timer to 30 milliseconds.
         *
         * @param saveDataTimerPeriod
         */
        fun saveDataTimerPeriod(saveDataTimerPeriod: Long = 30L) =
            apply { this.saveDataTimerPeriod = saveDataTimerPeriod }

        /**
         * Save matrix file indicating that the analysis matrix file should be saved.
         *
         * @param saveMatrixFile
         */
        fun saveMatrixFile(saveMatrixFile: Boolean = false) =
            apply { this.saveMatrixFile = saveMatrixFile }

        /**
         * Matrix file location specifying the file location path for storing Time-to-Collision (TTC) data (in this case, set to the cache directory)
         *
         * @param matrixFileLocation
         */
        fun matrixFileLocation(matrixFileLocation: FileLocationPath = FileLocationPath.CACHE) =
            apply { this.matrixFileLocation = matrixFileLocation }

        /**
         * Build and validate config
         *
         * if you enable analysis you need to set model name in asset folder
         *
         * @return [GizoAnalysisSettings]
         */
        fun build(): GizoAnalysisSettings {
            require(
                allowAnalysis.not() || (allowAnalysis && modelName.isEmpty().not())
            ) { "if you enable analysis you need to set model name in asset folder" }
            return GizoAnalysisSettings(
                allowAnalysis = allowAnalysis,
                modelName = modelName,
                carHeight = carHeight,
                collisionThreshold = collisionThreshold,
                saveTtcCsvFile = saveTtcCsvFile,
                ttcFileLocation = ttcFileLocation,
                saveDataTimerPeriod = saveDataTimerPeriod,
                saveMatrixFile = saveMatrixFile,
                matrixFileLocation = matrixFileLocation,
                tailgatingThreshold = tailgatingThreshold,
            )
        }

    }
}