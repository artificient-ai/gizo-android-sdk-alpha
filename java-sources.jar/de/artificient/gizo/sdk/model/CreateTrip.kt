package de.artificient.gizo.sdk.model

data class CreateTrip(val tripId: Long)
