package de.artificient.gizo.sdk.setting

import androidx.camera.video.Quality
import de.artificient.gizo.sdk.model.FileLocationPath

/**
 * Gizo video setting refer to the various options and configurations that allow users to control and customize the video recording.
 *
 * Gizo video setting is used to customize several behaviors and functionalities of the SDK, including specifying the quality of video capturing and the path to the saved video file.
 *
 * @property allowRecording to activate recording video or not.
 * @property quality to define the quality of video capturing, such as [Quality.SD], [Quality.HD], [Quality.FHD], [Quality.UHD], [Quality.LOWEST] and [Quality.HIGHEST].
 */
class GizoVideoSetting private constructor(
    val allowRecording: Boolean,
    val quality: Quality,
    val ai: Boolean,
) {

    /**
     * Use it to regenerate Builder from current options
     *
     * @return
     */
    fun toBuilder(): Builder = Builder().apply {
        allowRecording(allowRecording)
        quality(quality)
        ai(ai)
    }

    /**
     * Builder
     *
     * @constructor Create [GizoVideoSetting] instance.
     */
    class Builder() {
        private var allowRecording: Boolean = false
        private var quality: Quality = Quality.HD
        private var ai: Boolean = false

        /**
         * Allow recording to activate recording video or not.
         *
         * @param allowRecording
         */
        fun allowRecording(allowRecording: Boolean = false) =
            apply { this.allowRecording = allowRecording }

        /**
         * Quality to define the quality of video capturing, such as [Quality.SD], [Quality.HD], [Quality.FHD], [Quality.UHD], [Quality.LOWEST] and [Quality.HIGHEST].
         *
         * @param quality
         */
        fun quality(quality: Quality = Quality.HD) = apply { this.quality = quality }

        fun ai(ai: Boolean = false) =
            apply { this.ai = ai }

        fun build(): GizoVideoSetting {
            return GizoVideoSetting(
                allowRecording = allowRecording,
                quality = quality,
                ai = ai
            )
        }
    }
}