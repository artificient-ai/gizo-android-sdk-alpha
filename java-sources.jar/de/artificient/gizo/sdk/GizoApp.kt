package de.artificient.gizo.sdk

import android.content.Context
import de.artificient.gizo.sdk.setting.GizoOptions

/**
 * Gizo app
 *
 * @constructor Create empty Gizo app
 */
interface GizoApp {
    /**
     * Gizo analysis options.
     *
     * Variable to access current [GizoAppOptions]
     */
    val options: GizoOptions

    /**
     * Application context
     */
    val applicationContext: Context

//    /**
//     * Permission required
//     *
//     * Its gives us an array of strings that includes the required permissions based on [GizoAppOptions].
//     *
//     * | PERMISSIONS                | When                                                      |
//     * |----------------------------|-----------------------------------------------------------|
//     * | CAMERA                     | recording video or video analysis are allowed.            |
//     * | ACCESS_COARSE_LOCATION     | GPS setting is allowed.                                   |
//     * | ACCESS_FINE_LOCATION       | GPS setting is allowed.                                   |
//     * | READ_EXTERNAL_STORAGE      | saving files in download folder.                          |
//     * | WRITE_EXTERNAL_STORAGE     | saving files in download folder.                          |
//     * | WRITE_EXTERNAL_STORAGE     | saving files in download folder.                          |
//     * | ACTIVITY_RECOGNITION       | User Activity is allowed.                                 |
//     * | HIGH_SAMPLING_RATE_SENSORS | Android Api 31 or above Read Imu and user activity.       |
//     * | READ_PHONE_STATE           | Device Event setting is allowed.                          |
//     * | RECORD_AUDIO               | Device Event setting is allowed.                          |
//     * | OPSTR_GET_USAGE_STATS      | Android Api 29 above and Device Event setting is allowed. |
//     *
//     */
//    val permissionRequired: Array<String>

    /**
     * Gizo analysis
     *
     * Access to [GizoAnalysis]
     */
    val gizoAnalysis: GizoAnalysis

    /**
     * Setup
     *
     * Use it for re config [GizoApp] with new [GizoAppOptions]
     *
     * @param options [GizoAppOptions]
     *
     * @receiver [GizoApp]
     */
    fun setup(options: GizoOptions): GizoApp

    /**
     * Setup
     *
     * Use it for re config [GizoApp] with current [GizoAppOptions]
     *
     * @param changeConfig [Function] (options: [GizoAppOptions]) -> [GizoAppOptions])
     *
     * @receiver [GizoApp]
     */
    fun setup(changeConfig: (options: GizoOptions) -> GizoOptions): GizoApp

//    /**
//     * Load model
//     *
//     * Load model for [GizoAnalysis] with [GizoAnalysisSettings]
//     *
//     * It's allows the application to utilize the trained model's intelligence and perform complex tasks that go beyond traditional programming capabilities. By incorporating machine learning models into Android applications, developers can provide intelligent, data-driven features and functionalities to their users.
//     * Add these function in Application class to load the model and set the [setLoadModelObserver] for different status of [InterpreterStatus]
//     *
//     * Use [loadModelStatus] and [setLoadModelObserver] to observe [loadModel] status
//     */
//    fun loadModel()
//
//    /**
//     * Load model status
//     *
//     * Will show [loadModel] status as [InterpreterStatus] type.
//     */
//    val loadModelStatus: InterpreterStatus

//    /**
//     * Set load model observer
//     *
//     * Set listener for detect load model status [InterpreterStatus]
//     *
//     * @param observer it will return [InterpreterStatus]
//     * @receiver
//     */
//    fun setLoadModelObserver(observer: (status: InterpreterStatus) -> Unit): GizoApp
//
//    /**
//     * Release Model
//     *
//     * Release model loaded by [loadModel]
//     *
//     */
//    fun releaseModel()

//    /**
//     * check required Permission
//     *
//     * Based on [permissionRequired] and [GizoAppOptions].
//     *
//     * | PERMISSIONS                | When                                                      |
//     * |----------------------------|-----------------------------------------------------------|
//     * | CAMERA                     | recording video or video analysis are allowed.            |
//     * | ACCESS_COARSE_LOCATION     | GPS setting is allowed.                                   |
//     * | ACCESS_FINE_LOCATION       | GPS setting is allowed.                                   |
//     * | READ_EXTERNAL_STORAGE      | saving files in download folder.                          |
//     * | WRITE_EXTERNAL_STORAGE     | saving files in download folder.                          |
//     * | WRITE_EXTERNAL_STORAGE     | saving files in download folder.                          |
//     * | ACTIVITY_RECOGNITION       | User Activity is allowed.                                 |
//     * | HIGH_SAMPLING_RATE_SENSORS | Android Api 31 or above Read Imu and user activity.       |
//     * | READ_PHONE_STATE           | Device Event setting is allowed.                          |
//     * | RECORD_AUDIO               | Device Event setting is allowed.                          |
//     * | OPSTR_GET_USAGE_STATS      | Android Api 29 above and Device Event setting is allowed. |
//     */
//    fun checkAllPermissionGranted(context: Context): Boolean
}