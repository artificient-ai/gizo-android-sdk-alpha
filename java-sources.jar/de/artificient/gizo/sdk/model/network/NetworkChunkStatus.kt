package de.artificient.gizo.sdk.model.network

import de.artificient.gizo.sdk.model.ChunkStatus
import kotlinx.serialization.Serializable

@Serializable
data class NetworkChunkStatus(
    val fileChunkIds: List<Int>,
    val chunkSize: Int,
    val fileId: Long?,
    val isUploaded: Boolean,
    val uploadPercent: Int
)

fun NetworkChunkStatus.asChunkStatus() = ChunkStatus(
    fileChunkIds = fileChunkIds,
    chunkSize = chunkSize,
    fileId = fileId,
    isUploaded = isUploaded,
    uploadPercent = uploadPercent

)
