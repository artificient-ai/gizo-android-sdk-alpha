package de.artificient.gizo.sdk.model

/**
 * Enumerates the types of transitions that can occur for a user activity, represented by an integer value.
 *
 * @property transition The integer representation of the transition type.
 */
enum class UserActivityTransitionType(val transition: Int) {
    /**
     * Indicates the start of an activity.
     */
    STARTED(0),

    /**
     * Indicates the stop of an activity.
     */
    STOPPED(1)
}