package de.artificient.gizo.sdk.model

data class FrameSize(
    var width: Int = 1280,
    var height: Int = 720,
)