package de.artificient.gizo.sdk.model.network

import de.artificient.gizo.sdk.model.CreateTrip
import kotlinx.serialization.Serializable

@Serializable
data class NetworkCreateTrip(val tripId: Long)

fun NetworkCreateTrip.asCreateTripModel() = CreateTrip(
    tripId = tripId,
)

