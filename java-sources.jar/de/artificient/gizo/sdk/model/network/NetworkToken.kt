package de.artificient.gizo.sdk.model.network

import kotlinx.serialization.Serializable

@Serializable
data class NetworkToken(val token: String)

//fun NetworkUploadStart.asUploadStartModel() = de.artificient.gizo.sdk.model.UploadStart(
//    fileManagerId = fileManagerId,
//
//)

