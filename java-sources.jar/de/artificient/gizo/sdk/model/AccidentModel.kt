package de.artificient.gizo.sdk.model

data class AccidentModel(
    var time: String? = "",
    var latitude: Double? = null,
    var longitude: Double? = null,
    val speed: Int? = null,
    var acceleration: Double? = null,
    var severity:Int? = null,
    var uniqId: String? = "",

)