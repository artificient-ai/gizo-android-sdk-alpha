package de.artificient.gizo.sdk.service

import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import android.view.WindowManager
import androidx.camera.view.PreviewView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.OnLifecycleEvent
import androidx.lifecycle.lifecycleScope
import de.artificient.gizo.sdk.service.RecordingBackgroundService.Companion.startService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class CameraService(private val lifecycleOwner: LifecycleOwner, private val previewView: PreviewView) : LifecycleObserver {
    @SuppressLint("StaticFieldLeak")
    private var recordingCameraService: RecordingCameraService? = null
    val context = (lifecycleOwner as Context)

    @OnLifecycleEvent(Lifecycle.Event.ON_CREATE)
    fun onCreate() {
        onServiceBound(recordingCameraService)
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    fun onStart() {
        bindService()
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_STOP)
    fun onStop() {
        recordingCameraService?.startRunningInForeground()
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    fun onDestroy() {
        stopService()
    }

    private fun bindService() {
        val intent = Intent(context, RecordingCameraService::class.java)
        intent.action = RecordingCameraService.ACTION_START_WITH_PREVIEW
        context.startService(intent)
        context.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun stopService() {
        val intent = Intent(context, RecordingCameraService::class.java)
        context.unbindService(serviceConnection)
        context.stopService(intent)
    }

    private val serviceConnection: ServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            recordingCameraService =
                (service as RecordingCameraService.RecordingServiceBinder).getService()
            onServiceBound(recordingCameraService)
        }

        override fun onServiceDisconnected(name: ComponentName?) {
        }
    }

    private fun onServiceBound(recordingCameraService: RecordingCameraService?) {
        lifecycleOwner.lifecycleScope.launch {
            delay(500)
            recordingCameraService?.bindPreviewUseCase(previewView)
        }
    }
}