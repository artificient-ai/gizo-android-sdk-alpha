package de.artificient.gizo.sdk.setting

import de.artificient.gizo.sdk.model.FileLocationPath

/**
 * GPS settings in GIZO SDK allow developers to incorporate GPS functionality into their Android applications. This documentation provides instructions on enabling GPS, accessing location, speed, direction of movement (heading), and speed limit.
 *
 * @property allowGps allow access to GPS setting.
 * @property interval default interval between location updates.
 * @property maxWaitTime sets the maximum wait time in milliseconds for location updates. Locations determined at intervals but delivered in batch based on wait time. Batching is not supported by all engines.
 * @property saveCsvFile to save CSV file or not.
 * @property saveDataTimerPeriod is the period of time that a GPS data row is saved in CSV file.
 */
class GizoGpsSetting private constructor(
    val allowGps: Boolean,
    val interval: Long,
    val saveCsvFile: Boolean,
) {

    /**
     * Use it to regenerate Builder from current options
     *
     * @return
     */
    fun toBuilder(): Builder = Builder().apply {
        allowGps(allowGps)
        interval(interval)
        saveCsvFile(saveCsvFile)
    }

    /**
     * Builder
     *
     * @constructor Create [GizoGpsSetting] instance.
     */
    class Builder() {
        private var allowGps: Boolean = false
        private var mapBoxKey: String? = null
        private var interval: Long = 1000L
        private var saveCsvFile: Boolean = false

        /**
         * Allow gps allow access to GPS setting.
         *
         * @param allowGps
         */
        fun allowGps(allowGps: Boolean = false) = apply { this.allowGps = allowGps }

        /**
         * Interval default interval between location updates.
         *
         * @param interval
         */
        fun interval(interval: Long = 1000L) = apply { this.interval = interval }

        /**
         * Save csv file to save CSV file or not.
         *
         * @param saveCsvFile
         */
        fun saveCsvFile(saveCsvFile: Boolean = false) = apply { this.saveCsvFile = saveCsvFile }

        fun build(): GizoGpsSetting {

            return GizoGpsSetting(
                allowGps = allowGps,
                interval = interval,
                saveCsvFile = saveCsvFile,
            )
        }

    }
}