package de.artificient.gizo.sdk.model

/**
 * Enumerates specific state types for different device events detected by the SDK.
 * These states are associated with the [DeviceEventType]s and provide detailed information about the current state of the device's features.
 */
enum class DeviceEventStatus {
    /**
     * State indicating that the microphone is currently in use during a call.
     */
    MICROPHONE_IN_CALL,

    /**
     * State indicating that the microphone is available and not currently in use.
     */
    MICROPHONE_AVAILABLE,

    /**
     * State indicating that the screen is locked.
     */
    SCREEN_LOCKED,

    /**
     * State indicating that the screen is unlocked.
     */
    SCREEN_UNLOCK,

    /**
     * State indicating that the phone is currently ringing.
     */
    TELEPHONY_RINGING,

    /**
     * State indicating that the phone is idle, not in a call, and not ringing.
     */
    TELEPHONY_IDLE,

    /**
     * State indicating that the phone is off-hook, meaning a call is currently active.
     */
    TELEPHONY_OFF_HOOK,
}