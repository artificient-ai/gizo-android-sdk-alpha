package de.artificient.gizo.sdk.model.network

import kotlinx.serialization.Serializable

@Serializable
data class NetworkFilesCompletedStatus(
    val isCompleted: Boolean,
    val message: String,
)
