package de.artificient.gizo.sdk.setting

/**
 * Gizo orientation setting refers to the orientation of the screen of device, which can be either portrait (vertical) or landscape (horizontal). Proper orientation of the device is essential for AI analysis and recoding video. A proper orientation of the device means landscape orientation (horizontal) with +y axis parallel to the the +y axis of the vehicle coordinates system.
 *
 * @property allowGravitySensor to activate the gravity sensor or not.
 */
class GizoOrientationSetting private constructor(
    val allowGravitySensor: Boolean,
) {

    /**
     * Use it to regenerate Builder from current options
     *
     * @return
     */
    fun toBuilder(): Builder = Builder().apply {
        allowGravitySensor(allowGravitySensor)
    }

    /**
     * Builder
     *
     * @constructor Create [GizoOrientationSetting] instance.
     */
    class Builder() {
        private var allowGravitySensor: Boolean = false

        /**
         * Allow gravity sensor to activate the gravity sensor or not.
         *
         * @param allowGravitySensor
         */
        fun allowGravitySensor(allowGravitySensor: Boolean = false) =
            apply { this.allowGravitySensor = allowGravitySensor }

        /**
         * Build
         *
         * @return
         */
        fun build(): GizoOrientationSetting {
            return GizoOrientationSetting(
                allowGravitySensor = allowGravitySensor,
            )
        }
    }
}