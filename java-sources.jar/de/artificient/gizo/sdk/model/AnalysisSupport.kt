package de.artificient.gizo.sdk.model

data class AnalysisSupport(val androidVersion: Int, val appVersion: Int, val checked: Boolean)