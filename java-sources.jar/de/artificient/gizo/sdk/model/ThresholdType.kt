package de.artificient.gizo.sdk.model

/**
 * An enumeration class that represents the type of threshold.
 *
 * @property None no threshold
 */
enum class ThresholdType {
    None
}