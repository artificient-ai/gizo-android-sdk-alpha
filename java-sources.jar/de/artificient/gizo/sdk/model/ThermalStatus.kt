package de.artificient.gizo.sdk.model

/**
 * Enumerates the various thermal status levels that a device can report.
 * These status levels are indicative of the device's current thermal condition,
 * ranging from normal operating conditions to critical levels that may require immediate action.
 */
enum class ThermalStatus {
    /**
     * Indicates that the device is in a shutdown state due to excessive heat.
     */
    SHUTDOWN,

    /**
     * Indicates an emergency thermal condition that requires immediate attention to prevent damage.
     */
    EMERGENCY,

    /**
     * Represents a critical thermal status where the device is at risk and may automatically take action to cool down.
     */
    CRITICAL,

    /**
     * Indicates a severe thermal status that may start to throttle device performance to reduce heat.
     */
    SEVERE,

    /**
     * Represents a moderate thermal status where the device is warm but not yet at a point where performance is affected.
     */
    MODERATE,

    /**
     * Indicates a light thermal status with minimal impact on the device.
     */
    LIGHT,

    /**
     * Represents the normal operating temperature of the device.
     */
    NORMAL,

    /**
     * Indicates that no specific thermal status is reported, either due to lack of data or the device being within normal operating conditions.
     */
    NONE
}