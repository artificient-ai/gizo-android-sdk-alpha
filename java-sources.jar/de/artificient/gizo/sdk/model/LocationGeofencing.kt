package de.artificient.gizo.sdk.model

data class LocationGeofencing(
    val latitude: String? = null,
    val longitude: String? = null,
)