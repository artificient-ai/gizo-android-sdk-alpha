package de.artificient.gizo.sdk.model

enum class TransportationType(val value: Int) {
    Driver(0),
    Passenger(1),
    Subway(2),
    Train(3),
    Walking(4),
    Tram(5),
    Bus(6),
    Bike(7)
}