package de.artificient.gizo.sdk.setting

import de.artificient.gizo.sdk.model.FileLocationPath

class GizoStopRecordingSetting private constructor(
    val stopRecordingOnLowBatteryLevel: Int,
    val stopAiOnLowBatteryLevel: Int,
) {

    fun toBuilder(): Builder = Builder().apply {
        stopRecordingOnLowBatteryLevel(stopRecordingOnLowBatteryLevel)
        stopAiOnLowBatteryLevel(stopAiOnLowBatteryLevel)
    }

    class Builder() {
        private var stopRecordingOnLowBatteryLevel: Int = 15
        private var stopAiOnLowBatteryLevel: Int = 25

        fun stopRecordingOnLowBatteryLevel(stopRecordingOnLowBatteryLevel: Int = 15) =
            apply { this.stopRecordingOnLowBatteryLevel = stopRecordingOnLowBatteryLevel }

        fun stopAiOnLowBatteryLevel(stopAiOnLowBatteryLevel: Int = 25) =
            apply { this.stopAiOnLowBatteryLevel = stopAiOnLowBatteryLevel }

        fun build(): GizoStopRecordingSetting {
            return GizoStopRecordingSetting(
                stopRecordingOnLowBatteryLevel = stopRecordingOnLowBatteryLevel,
                stopAiOnLowBatteryLevel = stopAiOnLowBatteryLevel,
            )
        }
    }
}